<br />
<div align="center">
    <span style="font-size: 4em">📦</span>
  <h3 align="center">AppOS Starter Kit</h3>

  <p align="center">
    Quickly setup a simple app which includes AppOS SDK bundled in it.
    <br />
    <a href="https://learn.zoho.in/portal/zohocorp/team/appos-cloud/manual/appos-sdk"><strong>Explore the docs »</strong></a>
    <br />
    <br />
    <a href="https://workdrive.zohoexternal.in/embed/uc09202b9753ba1dc46a5baa0a3e586b7088f?toolbar=false&appearance=light&themecolor=green">View Demo</a>
    &middot;
    <a href="https://build.zohocorp.com/zoho/appos_starter/milestones/master/">Latest Milestone</a>
    &middot;
    <a href="https://code.zohocorpcloud.in/app#/zohoservices/new/APPOS_STARTER/197">Deploy in Code</a>
  </p>
</div>
