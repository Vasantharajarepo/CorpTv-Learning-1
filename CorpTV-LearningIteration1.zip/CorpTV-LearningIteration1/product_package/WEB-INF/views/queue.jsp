<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Queue - Business App</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
        background-color: #f4f4f4;
        color: #333;
        text-align: center;
      }
      .container {
        background-color: #fff;
        padding: 40px 60px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }
      h1 {
        color: #28a745;
      }
      p {
        font-size: 1.1em;
      }
      
      .form-container {
        margin-top: 30px;
        text-align: left;
      }
      
      .form-group {
        margin-bottom: 20px;
      }
      
      label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #333;
      }
      
      input[type="text"], textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background-color: #fff;
        color: #333;
        font-size: 14px;
        box-sizing: border-box;
      }
      
      input[type="text"]:focus, textarea:focus {
        border-color: #226db4;
        outline: none;
      }
      
      textarea {
        height: 120px;
        resize: vertical;
        font-family: 'Courier New', monospace;
      }
      
      .btn {
        background-color: #226db4;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        margin-right: 10px;
      }
      
      .btn:hover {
        background-color: #1a5a99;
      }
      
      .error {
        color: #e42527;
        font-size: 12px;
        margin-top: 5px;
        display: none;
      }
      
      .success {
        color: #28a745;
        font-size: 14px;
        margin-top: 10px;
        display: none;
      }
      
      .back-link {
        display: inline-block;
        margin-top: 25px;
        color: #e42527;
        text-decoration: none;
        font-size: 0.9em;
      }
      
      .back-link:hover {
        text-decoration: underline;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1 style="margin: 0">
        <span style="color: #226db4">Queue Events</span>
      </h1>
      <p style="margin: 10px 0; color: #e42527">Send events to the queue</p>
      
      <div class="form-container">
        <form id="queueForm" method="POST" action="/queue">
          <div class="form-group">
            <label for="eventName">Event Name:</label>
            <input type="text" id="eventName" name="eventName" placeholder="Enter event name" required>
            <div class="error" id="eventNameError">Event name is required.</div>
          </div>
          
          <div class="form-group">
            <label for="jsonData">JSON Data:</label>
            <textarea id="jsonData" name="jsonData" placeholder='{"key": "value", "number": 123}' required></textarea>
            <div class="error" id="jsonError">Please enter valid JSON data.</div>
          </div>
          
          <button type="submit" class="btn">Send Event</button>
          <button type="button" class="btn" onclick="clearForm()">Clear</button>
        </form>
        
        <div class="success" id="successMessage">Data sent successfully!</div>
        <div class="error" id="failureMessage">Data sent failed!</div>
      </div>
      
      <a href="/home" class="back-link">← Back to Home</a>
    </div>
    
    <script>
      // Show success message if success parameter is present
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('success') === 'true') {
        document.getElementById('successMessage').style.display = 'block';
        // Clear the URL parameter
        window.history.replaceState({}, document.title, window.location.pathname);
      }
      
      if (urlParams.get('success') === 'false') {
          document.getElementById('failureMessage').style.display = 'block';
          // Clear the URL parameter
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      
      
      function validateJSON(jsonString) {
        if (!jsonString.trim()) {
          return false; // Empty JSON is not allowed
        }
        try {
          JSON.parse(jsonString);
          return true;
        } catch (e) {
          return false;
        }
      }
      
      function clearForm() {
        document.getElementById('eventName').value = '';
        document.getElementById('jsonData').value = '';
        document.getElementById('eventNameError').style.display = 'none';
        document.getElementById('jsonError').style.display = 'none';
        document.getElementById('successMessage').style.display = 'none';
        document.getElementById('failureMessage').style.display = 'none';
      }
      
      document.getElementById('queueForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const eventName = document.getElementById('eventName').value.trim();
        const jsonData = document.getElementById('jsonData').value.trim();
        
        let isValid = true;
        
        // Reset error messages
        document.getElementById('eventNameError').style.display = 'none';
        document.getElementById('jsonError').style.display = 'none';
        document.getElementById('successMessage').style.display = 'none';
        
        // Validate event name
        if (!eventName) {
          document.getElementById('eventNameError').style.display = 'block';
          isValid = false;
        }
        
        // Validate JSON
        if (!validateJSON(jsonData)) {
          document.getElementById('jsonError').style.display = 'block';
          isValid = false;
        }
        
        if (isValid) {
          // Ensure JSON data is passed as a properly formatted string
          try {
            // Parse and stringify to ensure proper JSON formatting
            const parsedJson = JSON.parse(jsonData);
            document.getElementById('jsonData').value = JSON.stringify(parsedJson);
          } catch (e) {
            // If parsing fails, show error and don't submit
            document.getElementById('jsonError').style.display = 'block';
            document.getElementById('jsonData').style.borderColor = '#e42527';
            return; // Don't submit the form
          }
          
          // Submit the form
          this.submit();
        }
      });
      
      // Real-time JSON validation
      document.getElementById('jsonData').addEventListener('input', function() {
        const jsonData = this.value.trim();
        const errorElement = document.getElementById('jsonError');
        
        if (!validateJSON(jsonData)) {
          errorElement.style.display = 'block';
          this.style.borderColor = '#e42527';
        } else {
          errorElement.style.display = 'none';
          this.style.borderColor = '#ddd';
        }
      });
    </script>
  </body>
</html>
