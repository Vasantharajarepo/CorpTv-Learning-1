<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%><%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Business App</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
        background-color: #f4f4f4;
        color: #333;
        text-align: center;
      }
      .container {
        background-color: #fff;
        padding: 40px 60px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }
      h1 {
        color: #28a745; /* A nice green for "up and running" */
      }
      p {
        font-size: 1.1em;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1 style="margin: 0">
        <span style="color: #226db4">Business App</span>
      </h1>
      <p style="margin: 10px 0; color: #e42527">is up and running</p>
      <p style="margin: 10px 0; color: #e42527">Testing</p>
      <!-- Success or Error Messages -->
      <c:if test="${not empty status}">
        <div>Status: ${status}</div>
      </c:if>
      <style>
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
     </style>
    </div>
  </body>
</html>