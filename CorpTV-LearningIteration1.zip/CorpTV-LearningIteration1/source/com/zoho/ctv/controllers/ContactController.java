package com.zoho.ctv.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.ctv.models.Contact;
import com.zoho.ctv.services.ContactService;

/**
 * Controller class to handle contact-related requests.
 * This class provides endpoints to retrieve and create contacts.
 */
@RestController
@RequestMapping("/api") // NO I18N
public class ContactController {

    /**
     * Endpoint to retrieve all contacts.
     */
    @GetMapping(value = "/contacts")
    public List<Contact> getAllContacts() {
        return ContactService.getInstance().getAllContacts();
    }

    /**
     * Endpoint to retrieve a specific contact by ID.
     * Currently, this method is not implemented.
     */
    @GetMapping(value = "/contacts/{id}")
    public Contact getContactById(@PathVariable Long id) {
        return ContactService.getInstance().getContactById(id);
    }

    /**
     * Endpoint to update an existing contact.
     * This method allows partial updates to a contact's information.
     */
    @PutMapping(value = "/contacts") // No i18n
    public Contact updateContact(@RequestBody Contact contact) {
        return ContactService.getInstance().updateContact(contact);
    }

    /**
     * Endpoint to create a new contact.
     */
    @PostMapping("/contacts")
    public Contact createContact(@RequestBody Contact contact) {
        return ContactService.getInstance().createContact(contact);
    }
}
