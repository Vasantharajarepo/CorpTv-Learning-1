package com.zoho.ctv.controllers;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.ServiceOrg;
import com.adventnet.iam.ServiceOrgAPI;
import com.adventnet.iam.ServiceOrgProps;
import com.adventnet.iam.User;
import com.adventnet.iam.UserEmail;
import com.zoho.appos.iam.AppOSAuthProvider;
import com.zoho.appos.services.org.AppOSOrgInfo;
import com.zoho.appos.services.org.AppOSOrgService;
import com.zoho.ctv.handlers.AppOSOrgEventHandler;

@Controller
public class OrgController {

	@GetMapping("/")
	public String index() {
		return "redirect:/home.html"; // NO I18N
	}

	@GetMapping("/api/me") // NO I18N
	@ResponseBody
	public Map<String, Object> getCurrentUser(HttpServletRequest request) {
		User user = IAMUtil.getCurrentUser();
		String email = null;

		if (user != null) {
			List<UserEmail> emails = user.getEmails();
			if (emails != null && !emails.isEmpty()) {
				email = emails.get(0).getEmailId();
			}
		}

		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("email", email);
		return response;
	}

	@GetMapping("/api/orgs") // NO I18N
	@ResponseBody
	public ResponseEntity<Map<String, Object>> getOrgs() throws Exception {

		User user = IAMUtil.getCurrentUser();
		if (user == null) {
			Map<String, Object> unauthorized = new LinkedHashMap<String, Object>();
			unauthorized.put("message", "User is not logged in");
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(unauthorized);
		}

		Long zuid = Long.valueOf(user.getZuid());

		ServiceOrgAPI serviceOrgAPI = IAMProxy.getInstance().getServiceOrgAPI();
		int orgType = AppOSAuthProvider.getIAMServiceOrgType();

		List<AppOSOrgInfo> orgs = new ArrayList<AppOSOrgInfo>();

		List<ServiceOrg> serviceOrgs = serviceOrgAPI.getAllServiceOrgs(orgType, zuid);
		if (serviceOrgs != null) {
			for (ServiceOrg serviceOrg : serviceOrgs) {

				Long businessAppOrgId = serviceOrg.getZSOID();
				Long apposOrgId = -1L;

				ServiceOrgProps prop = serviceOrg.getServiceOrgProperty("APPOS_ORG_ID");
				if (prop != null) {
					apposOrgId = Long.valueOf(prop.getPropValue());

					AppOSOrgInfo apposOrgInfo = new AppOSOrgInfo();
					apposOrgInfo.setAppOsOrgId(apposOrgId);
					apposOrgInfo.setBusinessAppOrgId(businessAppOrgId);
					apposOrgInfo.setName(serviceOrg.getOrgName());

					orgs.add(apposOrgInfo);
				}
			}
		}

		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("orgs", orgs);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/api/orgs") // NO I18N
	@ResponseBody
	public ResponseEntity<Map<String, Object>> createOrg(@RequestBody(required = false) Map<String, String> data)
			throws Exception {
		User user = IAMUtil.getCurrentUser();
		if (user == null) {
			Map<String, Object> unauthorized = new LinkedHashMap<String, Object>();
			unauthorized.put("message", "User is not logged in");
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(unauthorized);
		}

		String fallbackOrgName = "Org #" + ThreadLocalRandom.current().nextInt(0, 100000); // NO I18N
		String orgName = fallbackOrgName;
		if (data != null) {
			String requestedOrgName = data.get("orgName");
			if (requestedOrgName != null && !requestedOrgName.trim().isEmpty()) {
				orgName = requestedOrgName.trim();
			}
		}
		String phone = "9282828777";
		String domain = "zohobapp" + ThreadLocalRandom.current().nextInt(0, 100000);

		AppOSOrgInfo context = new AppOSOrgInfo();
		context.setName(orgName);
		context.setPhoneNumber(phone);
		context.setDomainUrl(domain);

		AppOSOrgService.getInstance(context, new AppOSOrgEventHandler()).createOrg();

		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("success", true);
		response.put("message", "Organization created successfully");
		return ResponseEntity.ok(response);
	}
}
