package com.zoho.ctv.controllers;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.zoho.appos.iam.AppOSAuthProvider;
import com.zoho.appos.queue.api.EventPayload;
import com.zoho.appos.queue.api.EventProducer;
import com.zoho.components.kafka.logs.client.LogsKafkaProducer;
import com.zoho.conf.Configuration;

/**
 * Controller class to handle queue-related requests. This class provides endpoints for queue operations.
 */
@Controller
public class QueueController {

	/**
	 * Endpoint to display the queue page with "Hurray!" message.
	 * 
	 * @return ModelAndView pointing to the queue.jsp template
	 */
	@GetMapping("/queue")
	public ModelAndView queue() {
		return new ModelAndView("queue");
	}

	/**
	 * Endpoint to handle queue form submission. Accepts event name and JSON data, validates and processes them.
	 * 
	 * @param data
	 *            Form data containing eventName and jsonData
	 * @return ModelAndView redirecting back to queue page
	 */
	@PostMapping("/queue")
	public ModelAndView processQueue(@RequestParam Map<String, String> data) {
		String eventName = data.get("eventName");
		String jsonData = data.get("jsonData");
		
		JSONObject json = new JSONObject(jsonData);

		try {
			EventPayload payload = new EventPayload(eventName, json);
			EventProducer.produceMessage(payload);
		} catch (Exception e) {
			return new ModelAndView("redirect:/queue?success=false");
		}

		// Redirect back to the queue page with success parameter
		return new ModelAndView("redirect:/queue?success=true");
	}
}
