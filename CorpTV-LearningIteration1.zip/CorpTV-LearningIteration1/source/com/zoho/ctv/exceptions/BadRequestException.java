package com.zoho.ctv.exceptions;

/**
 * Represents an exception which will be
 * thrown when the request is malformed.
 */
public class BadRequestException extends InternalServerException {

	private static final long serialVersionUID = 1L;

	public BadRequestException() {
	}

	public BadRequestException(String message) {
		super(message);
	}
}
