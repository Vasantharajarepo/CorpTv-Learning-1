package com.zoho.ctv.exceptions;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

/**
 * Global exception handler to handle exceptions and return appropriate
 * responses based on the request type (JSON for REST clients, HTML for
 * browsers).
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(Exception.class)
	public Object handleException(Exception ex, WebRequest request, HttpServletRequest servletRequest) {

		String message = ex.getMessage();
		if (message == null) {
			message = "Something went wrong. Try again after some time."; // No i18n
		}

		Map<String, Object> body = new HashMap<>();
		body.put("status", HttpStatus.INTERNAL_SERVER_ERROR.name());
		body.put("message", message);
		return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(NotFoundException.class)
	public Object handleNotFoundException(Exception ex, WebRequest request, HttpServletRequest servletRequest) {

		String message = ex.getMessage();
		if (message == null) {
			message = "The requested resource was not found."; // No i18n
		}

		Map<String, Object> body = new HashMap<>();
		body.put("status", HttpStatus.NOT_FOUND.name());
		body.put("message", message);
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(UnauthorizedException.class)
	public Object handleUnauthorizedException(Exception ex, WebRequest request, HttpServletRequest servletRequest) {

		String message = ex.getMessage();
		if (message == null) {
			message = "You don't have permission for the requested resource."; // No i18n
		}

		Map<String, Object> body = new HashMap<>();
		body.put("status", HttpStatus.UNAUTHORIZED.name());
		body.put("message", message);
		return new ResponseEntity<>(body, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(BadRequestException.class)
	public Object handleBadRequestException(Exception ex, WebRequest request, HttpServletRequest servletRequest) {

		String message = ex.getMessage();
		if (message == null) {
			message = "The server could not understand the request due to invalid parameters."; // No i18n
		}

		Map<String, Object> body = new HashMap<>();
		body.put("status", HttpStatus.BAD_REQUEST.name());
		body.put("message", message);
		return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}
}
