package com.zoho.ctv.exceptions;

/**
 * Represents an exception which will be thrown
 * when something goes wrong on server-side.
 */
public class InternalServerException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InternalServerException() {
	}

	public InternalServerException(String message) {
		super(message);
	}
}
