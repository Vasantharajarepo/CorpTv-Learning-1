package com.zoho.ctv.exceptions;

/**
 * Represents an exception which will be
 * thrown when the request resource is not found.
 */
public class NotFoundException extends InternalServerException {

	private static final long serialVersionUID = 1L;

	public NotFoundException() {
	}

	public NotFoundException(String message) {
		super(message);
	}
}
