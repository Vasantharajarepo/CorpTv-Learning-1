package com.zoho.ctv.exceptions;

/**
 * Represents an exception which will be thrown
 * when the request resource is denied access.
 */
public class UnauthorizedException extends InternalServerException {

	private static final long serialVersionUID = 1L;

	public UnauthorizedException() {
	}

	public UnauthorizedException(String message) {
		super(message);
	}
}
