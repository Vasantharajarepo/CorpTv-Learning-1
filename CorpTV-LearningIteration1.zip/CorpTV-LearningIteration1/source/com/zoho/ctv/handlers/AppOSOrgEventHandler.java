package com.zoho.ctv.handlers;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.zoho.appos.api.HeaderMap;
import com.zoho.appos.api.ParameterMap;
import com.zoho.appos.api.modules.APIException;
import com.zoho.appos.api.modules.ActionHandler;
import com.zoho.appos.api.modules.ActionResponse;
import com.zoho.appos.api.modules.ActionWrapper;
import com.zoho.appos.api.modules.BodyWrapper;
import com.zoho.appos.api.modules.Modules;
import com.zoho.appos.api.modules.ModulesOperations;
import com.zoho.appos.api.modules.SuccessResponse;
import com.zoho.appos.api.profiles.MinifiedProfile;
import com.zoho.appos.api.profiles.Profile;
import com.zoho.appos.api.profiles.ProfilesOperations;
import com.zoho.appos.api.profiles.ResponseHandler;
import com.zoho.appos.api.profiles.ResponseWrapper;
import com.zoho.appos.api.util.APIResponse;
import com.zoho.appos.api.util.Model;
import com.zoho.appos.services.org.AppOSOrgHandler;
import com.zoho.appos.services.org.AppOSOrgInfo;

/**
 * Handles AppOS organization operations such as signup events.
 */
public class AppOSOrgEventHandler implements AppOSOrgHandler {

	private static final Logger LOGGER = Logger.getLogger(AppOSOrgEventHandler.class.getName());

	@Override
	public void onAfterOrgCreate(AppOSOrgInfo context) {

		ModulesOperations modulesOperations = new ModulesOperations();

		List<Modules> modules = new ArrayList<Modules>();

		Modules module = new Modules();
		module.setPluralLabel("Stocks"); // No i18n
		module.setSingularLabel("Stock"); // No i18n
		module.setAPIName("stock");

		List<MinifiedProfile> profiles = new ArrayList<MinifiedProfile>();
		MinifiedProfile profile = new MinifiedProfile();
		profile.setId(getProfileId());
		profiles.add(profile);
		module.setProfiles(profiles);

		modules.add(module);

		BodyWrapper request = new BodyWrapper();
		request.setModules(modules);

		try {
			APIResponse<ActionHandler> response = modulesOperations.createCustomModules(request);
			if (response != null) {
				LOGGER.info("Status Code: " + response.getStatusCode()); // No i18n
				if (response.isExpected()) {
					ActionHandler actionHandler = response.getObject();
					if (actionHandler instanceof ActionWrapper) {
						ActionWrapper actionWrapper = (ActionWrapper) actionHandler;
						List<ActionResponse> actionResponses = actionWrapper.getModules();
						for (ActionResponse actionResponse : actionResponses) {
							if (actionResponse instanceof SuccessResponse) {
								SuccessResponse successResponse = (SuccessResponse) actionResponse;
								LOGGER.info("Status: " + successResponse.getStatus().getValue()); // No i18n
								LOGGER.info("Code: " + successResponse.getCode().getValue()); // No i18n
								LOGGER.info("Details: "); // No i18n
								for (Map.Entry<String, Object> entry : successResponse.getDetails().entrySet()) {
									LOGGER.info(entry.getKey() + ": " + entry.getValue()); // No i18n
								}
								LOGGER.info("Message: " + successResponse.getMessage()); // No i18n
							} else if (actionResponse instanceof APIException) {
								APIException exception = (APIException) actionResponse;
								LOGGER.info("Status: " + exception.getStatus().getValue()); // No i18n
								LOGGER.info("Code: " + exception.getCode().getValue()); // No i18n
								LOGGER.info("Details: "); // No i18n
								for (Map.Entry<String, Object> entry : exception.getDetails().entrySet()) {
									LOGGER.info(entry.getKey() + ": " + entry.getValue()); // No i18n
								}
								LOGGER.info("Message: " + exception.getMessage()); // No i18n
							}
						}
					} else if (actionHandler instanceof APIException) {
						APIException exception = (APIException) actionHandler;
						LOGGER.info("Status: " + exception.getStatus().getValue()); // No i18n
						LOGGER.info("Code: " + exception.getCode().getValue()); // No i18n
						LOGGER.info("Details: "); // No i18n
						if (exception.getDetails() != null) {
							for (Map.Entry<String, Object> entry : exception.getDetails().entrySet()) {
								LOGGER.info(entry.getKey() + ": " + entry.getValue()); // No i18n
							}
						}
						LOGGER.info("Message: " + exception.getMessage()); // No i18n
					}
				} else {
					Model responseObject = response.getModel();
					Class<? extends Model> clas = responseObject.getClass();
					Field[] fields = clas.getDeclaredFields();
					for (Field field : fields) {
						field.setAccessible(true);
						LOGGER.info(field.getName() + ":" + field.get(responseObject)); // No i18n
					}
				}
			}
		} catch (Exception e) {

		}
	}

	private static Long getProfileId() {

		ProfilesOperations profilesOperations = new ProfilesOperations();
		ParameterMap paramInstance = new ParameterMap();
		HeaderMap headerInstance = new HeaderMap();
		try {
			APIResponse<ResponseHandler> response = profilesOperations.getProfiles(paramInstance, headerInstance);

			if (response != null) {
				LOGGER.info("Status Code: " + response.getStatusCode()); // No i18n
				if (response.isExpected()) {
					ResponseHandler responseHandler = response.getObject();
					if (responseHandler instanceof ResponseWrapper) {
						ResponseWrapper responseWrapper = (ResponseWrapper) responseHandler;
						List<Profile> profiles = responseWrapper.getProfiles();
						for (Profile profile : profiles) {
							return profile.getId();
						}
					} else if (responseHandler instanceof APIException) {
						APIException exception = (APIException) responseHandler;
						LOGGER.info("Status: " + exception.getStatus().getValue()); // No i18n
						LOGGER.info("Code: " + exception.getCode().getValue()); // No i18n
						LOGGER.info("Details: "); // No i18n
						for (Map.Entry<String, Object> entry : exception.getDetails().entrySet()) {
							LOGGER.info(entry.getKey() + ": " + entry.getValue()); // No i18n
						}
						LOGGER.info("Message: " + exception.getMessage()); // No i18n
					}
				} else {
					Model responseObject = response.getModel();
					Class<? extends Model> clas = responseObject.getClass();
					java.lang.reflect.Field[] fields = clas.getDeclaredFields();
					for (java.lang.reflect.Field field : fields) {
						field.setAccessible(true);
						LOGGER.info(field.getName() + ":" + field.get(responseObject)); // No i18n
					}
				}
			}
		} catch (Exception e) {
			LOGGER.warning("Something went wrong due to " + e);
		}

		return null;
	}

	@Override
	public void onBeforeOrgCreate(AppOSOrgInfo context) {
	}

}
