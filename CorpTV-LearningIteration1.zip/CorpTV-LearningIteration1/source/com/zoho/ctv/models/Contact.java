package com.zoho.ctv.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.zoho.appos.api.record.Field;
import com.zoho.appos.api.record.Record;
import com.zoho.appos.api.util.Choice;

/**
 * Represents a contact with basic information.
 */
@JsonInclude(Include.NON_NULL)
public class Contact extends Model {

    public Contact() {
        setSalutation("-None-");
    }

    public static class Fields {
        public static final String ID = Field.Contacts.ID.getAPIName();
        public static final String FULL_NAME = Field.Contacts.FULL_NAME.getAPIName();
        public static final String FIRST_NAME = Field.Contacts.FIRST_NAME.getAPIName();
        public static final String LAST_NAME = Field.Contacts.LAST_NAME.getAPIName();
        public static final String EMAIL = Field.Contacts.EMAIL.getAPIName();
        public static final String PHONE = Field.Contacts.PHONE.getAPIName();
        public static final String SALUTATION = Field.Contacts.SALUTATION.getAPIName();
    }

    @SuppressWarnings("unchecked") // No i18n
    public Contact(Record record) {
        setId(record.getId());
        setFullName((String) record.getKeyValue(Fields.FULL_NAME));
        setFirstName((String) record.getKeyValue(Fields.FIRST_NAME));
        setLastName((String) record.getKeyValue(Fields.LAST_NAME));
        setEmail((String) record.getKeyValue(Fields.EMAIL));
        setMobile((String) record.getKeyValue(Fields.PHONE));

        Choice<String> salutation = (Choice<String>) record.getKeyValue(Fields.SALUTATION);
        if (salutation != null) {
            setSalutation(salutation.getValue());
        }
    }

    public String getFirstName() {
        return (String) getFieldValue(Fields.FIRST_NAME);
    }

    public void setFirstName(String firstName) {
        addFieldValue(Fields.FIRST_NAME, firstName);
    }

    public String getLastName() {
        return (String) getFieldValue(Fields.LAST_NAME);
    }

    public void setLastName(String lastName) {
        addFieldValue(Fields.LAST_NAME, lastName);
    }

    @SuppressWarnings("unchecked")
    public String getSalutation() {
        Choice<String> salutation = (Choice<String>) getFieldValue(Fields.SALUTATION);
        if (salutation != null) {
            return salutation.getValue();
        }
        return null;
    }

    public void setSalutation(String salutation) {
        addFieldValue(Fields.SALUTATION, new Choice<String>(salutation));
    }

    public String getEmail() {
        return (String) getFieldValue(Fields.EMAIL);
    }

    public void setEmail(String email) {
        addFieldValue(Fields.EMAIL, email);
    }

    public String getMobile() {
        return (String) getFieldValue(Fields.PHONE);
    }

    public void setMobile(String mobile) {
        addFieldValue(Fields.PHONE, mobile);
    }

    public Long getId() {
        return (Long) getFieldValue(Fields.ID);
    }

    public void setId(Long id) {
        addFieldValue(Fields.ID, id);
    }

    public String getFullName() {
        return (String) getFieldValue(Fields.FULL_NAME);
    }

    public void setFullName(String fullName) {
        addFieldValue(Fields.FULL_NAME, fullName);
    }
}