package com.zoho.ctv.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.zoho.appos.api.record.Record;

/**
 * Represents a model that contains a list of triggers
 * and a Record object to hold field values.
 * 
 * Provides methods to manipulate the record and its fields.
 */
public class Model {

    @JsonIgnore
    private List<String> triggers;

    @JsonIgnore
    private Record record;

    protected Model() {
        setRecord(new Record());
        List<String> triggers = new ArrayList<>();
        triggers.add("workflow"); // No i18n
        triggers.add("approval"); // No i18n
        triggers.add("blueprint"); // No i18n
        triggers.add("pathfinder"); // No i18n
        triggers.add("orchestration"); // No i18n
        setTriggers(triggers);
    }

    public List<String> getTriggers() {
        return triggers;
    }

    public void setTriggers(List<String> triggers) {
        this.triggers = triggers;
    }

    private void setRecord(Record record) {
        this.record = record;
    }

    protected void addFieldValue(String fieldName, Object value) {
        this.record.addKeyValue(fieldName, value);
    }

    public Record toRecord() {
        return this.record;
    }

    protected Object getFieldValue(String fieldName) {
        return this.record.getKeyValue(fieldName);
    }

    @JsonSerialize(using = ToStringSerializer.class)
    public Long getId() {
        return (Long) getFieldValue("id");
    }

    public void setId(Long id) {
        addFieldValue("id", id);
    }
}
