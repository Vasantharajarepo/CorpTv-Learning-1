package com.zoho.ctv.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.appos.api.record.Record;
import com.zoho.appos.services.records.RecordService;
import com.zoho.appos.services.records.RecordServiceException;
import com.zoho.ctv.models.Contact;
import com.zoho.ctv.exceptions.BadRequestException;
import com.zoho.ctv.exceptions.InternalServerException;
import com.zoho.ctv.exceptions.NotFoundException;
import com.zoho.ctv.exceptions.UnauthorizedException;

/**
 * Singleton service class to manage contacts using RecordService utils.
 */
public class ContactService {
	private static final Logger LOGGER = Logger.getLogger(ContactService.class.getName());
	private static ContactService instance;
	private static final String MODULE = "Contacts";

	private ContactService() {
	}

	public static ContactService getInstance() {
		if (instance == null) {
			instance = new ContactService();
		}
		return instance;
	}

	/**
	 * Retrieves a list of all contacts.
	 */
	public List<Contact> getAllContacts() {
		List<Contact> contacts = new ArrayList<>();
		try {
			List<String> fieldNames = List.of(
					Contact.Fields.FULL_NAME,
					Contact.Fields.EMAIL,
					Contact.Fields.SALUTATION,
					Contact.Fields.PHONE);
			List<Record> records = RecordService.getRecords(MODULE,
					RecordService.GetRecordsOptions.builder()
							.fields(fieldNames)
							.converted("false")
							.build());
			for (Record record : records) {
				contacts.add(new Contact(record));
			}
		} catch (RecordServiceException.NoPermissionException e) {
			throw new UnauthorizedException("You don't have permission to view contacts.");
		} catch (RecordServiceException.InvalidModuleException e) {
			throw new NotFoundException("Contacts module not found.");
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "Failed to retrieve all contacts due to ", e);
			throw new InternalServerException("Failed to retrieve all contacts.");
		}
		return contacts;
	}

	/**
	 * Retrieves a contact by its ID.
	 */
	public Contact getContactById(Long id) {
		try {
			Optional<Record> recordOpt = RecordService.getRecordById(MODULE, id);
			if (recordOpt.isPresent()) {
				return new Contact(recordOpt.get());
			}
			throw new NotFoundException("No contact found with the given information.");
		} catch (RecordServiceException.NoPermissionException e) {
			throw new UnauthorizedException("You don't have permission to view this contact.");
		} catch (RecordServiceException.InvalidModuleException e) {
			throw new NotFoundException("Contacts module not found.");
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "Failed to retrieve a contact due to ", e);
			throw new InternalServerException("Failed to retrieve a contact.");
		}
	}

	/**
	 * Creates a new contact.
	 */
	public Contact createContact(Contact contact) {
		try {			
			Long createdId = RecordService.createRecord(MODULE, contact.toRecord());
			Optional<Record> created = RecordService.getRecordById(MODULE, createdId);
			return new Contact(created.get());
		} catch (RecordServiceException.AuthorizationFailedException | RecordServiceException.NoPermissionException e) {
			throw new UnauthorizedException("You don't have permission to create a contact.");
		} catch (RecordServiceException.DuplicateDataException e) {
			throw new BadRequestException("A contact with same information already exists.");
		} catch (RecordServiceException.MandatoryNotFoundException e) {
			throw new BadRequestException("Some mandatory fields are left empty.");
		} catch (RecordServiceException.InvalidDataException e) {
			throw new BadRequestException("One or more fields has invalid data.");
		} catch (RecordServiceException.InvalidModuleException e) {
			throw new NotFoundException("Contacts module not found.");
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "Failed to create a contact due to ", e);
			throw new InternalServerException("Failed to create a contact.");
		}
	}

	/**
	 * Updates a contact with the given information.
	 */
	public Contact updateContact(Contact contact) {
		try {
			Record updated = RecordService.updateAndGetRecord(MODULE, contact.getId(), contact.toRecord());
			return new Contact(updated);
		} catch (RecordServiceException.AuthorizationFailedException | RecordServiceException.NoPermissionException e) {
			throw new UnauthorizedException("You don't have permission to update a contact.");
		} catch (RecordServiceException.DuplicateDataException e) {
			throw new BadRequestException("A contact with same information already exists.");
		} catch (RecordServiceException.MandatoryNotFoundException e) {
			throw new BadRequestException("Some mandatory fields are left empty.");
		} catch (RecordServiceException.InvalidDataException e) {
			throw new BadRequestException("One or more fields has invalid data.");
		} catch (RecordServiceException.InvalidModuleException e) {
			throw new NotFoundException("Contacts module not found.");
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "Failed to update the contact due to ", e);
			throw new InternalServerException("Failed to update the contact with the given information.");
		}
	}
}
