//$Id$
package com.zoho.ctv.test;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.adventnet.taskengine.inmemory.TaskExecutor;
import com.zoho.appos.scheduler.inmemory.AppOSInmemoryTaskCallable;
import com.zoho.appos.scheduler.inmemory.AppOSInmemoryTaskExecutor;
import com.zoho.appos.scheduler.inmemory.AppOSInmemoryTaskScheduler;


public class AppOSInmemoryTaskSchedulerTest{
	
	private static final Logger LOGGER = Logger.getLogger(AppOSInmemoryTaskSchedulerTest.class.getName());
	public void startTest() {
        try {
            LOGGER.info("=== Starting AppOSInmemoryTaskSchedulerTest Lifecycle Test ===");
            scheduleTask();
            

            LOGGER.info("=== AppOSInmemoryTaskSchedulerTest Lifecycle Test Completed Successfully ===");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in startTest()", e);
        }
    }

    private void scheduleTask() {
    	try {
			TaskExecutor taskExecuter = AppOSInmemoryTaskScheduler.getExecutor();
			Class<?> clazz = Class.forName("com.zoho.ctv.test.AppOSInmemoryTaskSchedulerTest");
			Object callingObj = new AppOSInmemoryTaskSchedulerTest();
			Object obj = clazz.getDeclaredConstructor().newInstance();
			Class<?>[] paramTypes = null;
			Object[] params = null;
			// Task submitted using callable
			taskExecuter.submit( new AppOSInmemoryTaskCallable("com.zoho.ctv.test.AppOSInmemoryTaskSchedulerTest", "run", paramTypes, params));
			taskExecuter.submit( new AppOSInmemoryTaskCallable(callingObj, "run", paramTypes, params));
			// Task submitted using runnable
			taskExecuter.submit( new AppOSInmemoryTaskExecutor("com.zoho.ctv.test.AppOSInmemoryTaskSchedulerTest", "run", paramTypes, params)); //No I18N
			taskExecuter.submit( new AppOSInmemoryTaskExecutor(callingObj, "run", paramTypes, params)); //No I18N
    	 } catch (Exception e) {
             LOGGER.log(Level.SEVERE, "Exception in startTest()", e);
         }
		
	}

	public static void run() {
        long i = 10L;
        LOGGER.info("Run method executed");
    }
}
