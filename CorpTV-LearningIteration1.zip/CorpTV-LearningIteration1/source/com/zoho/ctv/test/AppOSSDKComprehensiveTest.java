//$Id$
package com.zoho.ctv.test;

import java.util.logging.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Main test controller for AppOS SDK comprehensive testing.
 * 
 * This controller provides the endpoint to run all test suites:
 * - CustomModuleCRUDTest: Tests custom module CRUD operations
 * - ConfigModuleCRUDTest: Tests config module CRUD operations
 * - ConnectionPoolingTest: Tests connection pooling functionality
 * 
 * Endpoint: /basictesting
 * 
 * @author AppOS SDK Team
 * @version 1.0
 * @since SDK v18.0.0
 */
@Controller
public class AppOSSDKComprehensiveTest {
    
    private static final Logger LOGGER = Logger.getLogger(AppOSSDKComprehensiveTest.class.getName());
    
    /**
     * Run all comprehensive tests
     * @return ModelAndView with test results
     */
    @GetMapping("/basictesting")
    public ModelAndView runAllTests() {
        String status = "";
        ModelAndView model = new ModelAndView("testing"); // NO I18N
        
        try {
            CustomModuleCRUDTest basic = new CustomModuleCRUDTest();
            basic.runCustomModuleTests();
            status = status + "CustomModuleCRUDTests Success"; // no i18n
        } catch (Exception e) {
            status = status + "CustomModuleCRUDTests Failed: " + e.getMessage(); // no i18n
        }
        
        try {
            ConfigModuleCRUDTest config = new ConfigModuleCRUDTest();
            config.runAllConfigTests();
            status = status + ";;; ConfigModuleCRUD Success"; // no i18n
        } catch (Exception e) {
            status = status + ";;; ConfigModuleCRUD Failed: " + e.getMessage(); // no i18n
        }
        
        try {
            ConnectionPoolingTest connPooling = new ConnectionPoolingTest();
            connPooling.runAllConnectionPoolingTests();
            status = status + ";;; ConnectionPoolingTest Success"; // no i18n
        } catch (Exception e) {
            status = status + ";;; ConnectionPoolingTest Failed: " + e.getMessage(); // no i18n
        }
        
        model.addObject("status", status); // no i18n
        return model;
    }
}
