//$Id$
package com.zoho.ctv.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.appos.api.HeaderMap;
import com.zoho.appos.api.ParameterMap;
import com.zoho.appos.api.fields.Fields;
import com.zoho.appos.api.fields.FieldsOperations;
import com.zoho.appos.api.modules.ActionHandler;
import com.zoho.appos.api.modules.Modules;
import com.zoho.appos.api.modules.ModulesOperations;
import com.zoho.appos.api.profiles.MinifiedProfile;
import com.zoho.appos.api.profiles.Profile;
import com.zoho.appos.api.profiles.ProfilesOperations;
import com.zoho.appos.api.profiles.ResponseWrapper;
import com.zoho.appos.api.record.RecordOperations;
import com.zoho.appos.api.util.APIResponse;

/**
 * Comprehensive test suite for Config Module CRUD operations in AppOS SDK
 * 
 * NEW FEATURES IN SDK v18.0.0 (Feb 25, 2026):
 * ============================================
 * 
 * MODULE OPERATIONS:
 * - createConfigModules() - Create configuration modules
 * - getConfigModules() - List all configuration modules
 * - getConfigModuleByAPIName() - Get specific config module by API name
 * - updateConfigModule() - Update configuration module
 * - deleteConfigModule() - Delete configuration module (not fully supported yet)
 * 
 * FIELD OPERATIONS:
 * - createField() with MODULE parameter for config modules
 * - getConfigFields() - Get fields for config modules
 * - getField() with MODULE parameter
 * - updateField() with MODULE parameter
 * - deleteField() with MODULE parameter
 * 
 * RECORD OPERATIONS (Config-specific):
 * - createConfigRecords() - Create records in config modules
 * - getConfigRecord() - Get single config record
 * - getConfigRecords() - Get all config records
 * - updateConfigRecord() - Update config record
 * - deleteConfigRecord() - Delete config record
 * 
 * USAGE:
 * <pre>
 * ConfigModuleCRUDTest test = new ConfigModuleCRUDTest();
 * test.runAllConfigTests(); // Run complete lifecycle test
 * 
 * // Or run individual test suites:
 * test.testConfigModuleOperations();
 * test.testConfigFieldOperations();
 * test.testConfigRecordOperations();
 * </pre>
 * 
 * @author AppOS SDK Team
 * @version 1.0
 * @since SDK v18.0.0
 */
public class ConfigModuleCRUDTest {

    private static final Logger LOGGER = Logger.getLogger(ConfigModuleCRUDTest.class.getName());
    
    // Test Configuration - Unique module names using random number
    private String number = ThreadLocalRandom.current().nextInt(0, 100000) + ""; // no i18n
    private String testModulePrefix = "TestConfig" + number; // no i18n
    
    // Cached profile ID fetched from API
    private Long cachedStandardProfileId = null;
    
    // Test Data Storage
    private String currentModuleAPIName;
    private Long currentFieldId;
    private Long currentRecordId;
    
    /**
     * Run complete Config Module lifecycle test
     * Tests all CRUD operations in proper sequence
     * @throws Exception if any test fails
     */
    public void runAllConfigTests() throws Exception {
        LOGGER.info("=====================================================");
        LOGGER.info("    Config Module CRUD Test Suite - SDK v18.0.0");
        LOGGER.info("=====================================================\n");
        
        try {
            // Phase 1: Module Operations
            testConfigModuleOperations();
            
            // Phase 2: Field Operations (requires module)
            if (currentModuleAPIName != null) {
                testConfigFieldOperations();
            } else {
                throw new Exception("Module creation failed. Cannot proceed with Field operations.");
            }
            
            // Phase 3: Record Operations (requires module and fields)
            if (currentModuleAPIName != null && currentFieldId != null) {
                testConfigRecordOperations();
            } else {
                throw new Exception("Field creation failed. Cannot proceed with Record operations.");
            }
            
            // Phase 4: Advanced Operations
            testBatchConfigOperations();
            testConfigModuleValidations();
            
            // Phase 5: Cleanup
            cleanup();
            
            LOGGER.info("\n=====================================================");
            LOGGER.info("    All Config Module Tests Completed Successfully!");
            LOGGER.info("=====================================================");
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Test suite failed", e);
            throw e; // Re-throw exception
        }
    }
    
    // ==================== MODULE OPERATIONS ====================
    
    /**
     * TEST SUITE 1: Config Module CRUD Operations
     * 
     * Tests:
     * 1. Create config module with all properties
     * 2. Get config module by API name
     * 3. List all config modules
     * 4. Update config module
     * 5. Delete config module (if supported)
     * @throws Exception if module operations fail
     */
    public void testConfigModuleOperations() throws Exception {
        LOGGER.info("\n");
        LOGGER.info("  TEST SUITE 1: Config Module CRUD Operations     ");
        LOGGER.info("\n");
        
        // Test 1.1: Create Config Module with Basic Properties
        createBasicConfigModule();
        
        // Test 1.2: Get Config Module by API Name
        if (currentModuleAPIName != null) {
            getConfigModuleByAPIName(currentModuleAPIName);
        } else {
            throw new Exception("Module creation failed. currentModuleAPIName is null.");
        }
        
        // Test 1.3: List All Config Modules
        listAllConfigModules();
        
        LOGGER.info("Module operations test suite completed\n");
    }
    
    /**
     * Test 1.1: Create basic config module
     * @throws Exception if module creation fails
     */
    private void createBasicConfigModule() throws Exception {
        LOGGER.info("[Test 1.1] Creating basic config module...");
        
        currentModuleAPIName = testModulePrefix + "Basic"; // no i18n
        
        ModulesOperations modulesOps = new ModulesOperations();
        com.zoho.appos.api.modules.BodyWrapper wrapper = new com.zoho.appos.api.modules.BodyWrapper();
        
        List<Modules> modules = new ArrayList<>();
        Modules module = new Modules();
        module.setAPIName(currentModuleAPIName);
        module.setPluralLabel(testModulePrefix + " Items"); // no i18n
        module.setSingularLabel(testModulePrefix + " Item"); // no i18n
        module.setCategory("configuration"); // Required for config modules // no i18n
        module.setAuthType("self"); // Authorization type // no i18n
        
        // Display field is MANDATORY for config modules
        JSONObject displayField = new JSONObject();
        displayField.put("field_label", "Name"); // no i18n
        displayField.put("data_type", "text"); // no i18n
        displayField.put("length", 250); // no i18n
        module.setDisplayField(displayField);
        
        // Profile is MANDATORY for module creation - fetch dynamically
        Long profileId = getStandardProfileId();
        if (profileId == null) {
            throw new Exception("Could not fetch profile ID. Profile is mandatory for module creation.");
        }
        
        List<MinifiedProfile> profiles = new ArrayList<>();
        MinifiedProfile profile = new MinifiedProfile();
        profile.setId(profileId);
        profiles.add(profile);
        module.setProfiles(profiles);
        LOGGER.info("Using Profile ID: " + profileId);
        
        modules.add(module);
        wrapper.setModules(modules);
        
        APIResponse<ActionHandler> response = modulesOps.createConfigModules(wrapper);
        logAPIResponse("Create Basic Config Module", response);
        
        LOGGER.info("Basic config module created successfully: " + currentModuleAPIName);
    }
    
    /**
     * Test 1.2: Get config module by API name
     * @param apiName API name of the module to fetch
     * @throws Exception if get operation fails
     */
    private void getConfigModuleByAPIName(String apiName) throws Exception {
        LOGGER.info("[Test 1.2] Getting config module by API name: " + apiName);
        
        ModulesOperations ops = new ModulesOperations();
        APIResponse<com.zoho.appos.api.modules.ResponseHandler> response = 
            ops.getConfigModuleByAPIName(apiName);
        
        logAPIResponse("Get Config Module by API Name", response);
        
        // Verify module properties
        if (response.getResponseJSON() instanceof JSONObject) {
            JSONObject json = (JSONObject) response.getResponseJSON();
            if (json.has("modules")) { // no i18n
                JSONArray modulesArr = json.getJSONArray("modules"); // no i18n
                if (modulesArr.length() > 0) {
                    JSONObject moduleJson = modulesArr.getJSONObject(0);
                    LOGGER.info("  - Module ID: " + moduleJson.opt("id")); // no i18n
                    LOGGER.info("  - API Name: " + moduleJson.opt("api_name")); // no i18n
                    LOGGER.info("  - Category: " + moduleJson.opt("category")); // no i18n
                    LOGGER.info("  - Auth Type: " + moduleJson.opt("auth_type")); // no i18n
                }
            }
        }
        
        LOGGER.info("Successfully fetched config module: " + apiName);
    }
    
    /**
     * Test 1.3: List all config modules
     * @throws Exception if list operation fails
     */
    private void listAllConfigModules() throws Exception {
        LOGGER.info("[Test 1.3] Listing all config modules...");
        
        ModulesOperations ops = new ModulesOperations();
        ParameterMap params = new ParameterMap();
        HeaderMap headers = new HeaderMap();
        
        APIResponse<com.zoho.appos.api.modules.ResponseHandler> response = 
            ops.getConfigModules(params, headers);
        
        logAPIResponse("List All Config Modules", response);
        
        if (response.getResponseJSON() instanceof JSONObject) {
            JSONObject json = (JSONObject) response.getResponseJSON();
            if (json.has("modules")) { // no i18n
                JSONArray modulesArr = json.getJSONArray("modules"); // no i18n
                LOGGER.info("Found " + modulesArr.length() + " config modules");
                
                for (int i = 0; i < modulesArr.length(); i++) {
                    JSONObject moduleJson = modulesArr.getJSONObject(i);
                    LOGGER.info("  " + (i+1) + ". " + moduleJson.optString("api_name") + // no i18n
                              " (" + moduleJson.optString("category") + ")"); // no i18n
                }
            }
        }
    }
    
    // ==================== FIELD OPERATIONS ====================
    
    /**
     * TEST SUITE 2: Config Field CRUD Operations
     * @throws Exception if field operations fail
     */
    public void testConfigFieldOperations() throws Exception {
        LOGGER.info("\n");
        LOGGER.info("  TEST SUITE 2: Config Field CRUD Operations      ");
        LOGGER.info("\n");
        
        // Test 2.1: Create Text Field
        currentFieldId = createTextField();
        if (currentFieldId == null) {
            throw new Exception("Failed to create text field. Field ID is null.");
        }
        
        // Test 2.4: Get Field by ID
        getConfigFieldById(currentFieldId);
        
        // Test 2.5: Get All Config Fields
        getAllConfigFields();
        
        // Test 2.6: Update Field
        updateConfigField(currentFieldId);
        
        LOGGER.info("Field operations test suite completed\n");
    }
    
    /**
     * Test 2.1: Create text field in config module
     * @return Field ID of created field
     * @throws Exception if field creation fails
     */
    private Long createTextField() throws Exception {
        LOGGER.info("[Test 2.1] Creating text field in config module...");
        
        FieldsOperations ops = new FieldsOperations();
        com.zoho.appos.api.fields.BodyWrapper wrapper = new com.zoho.appos.api.fields.BodyWrapper();
        
        List<Fields> fields = new ArrayList<>();
        Fields field = new Fields();
        field.setFieldLabel("ItemName"); // no i18n
        field.setDataType("text"); // no i18n
        field.setLength(250);
        field.setFilterable(true);
        field.setSearchable(true);
        fields.add(field);
        wrapper.setFields(fields);
        
        ParameterMap params = new ParameterMap();
        params.add(FieldsOperations.CreateFieldParam.MODULE, currentModuleAPIName);
        
        APIResponse<com.zoho.appos.api.fields.ActionHandler> response = 
            ops.createField(wrapper, params);
        logAPIResponse("Create Text Field", response);
        
        Long fieldId = extractFieldId(response);
        if (fieldId == null) {
            throw new Exception("Could not extract field ID from response.");
        }
        
        LOGGER.info("Text field created with ID: " + fieldId);
        return fieldId;
    }
    
    /**
     * Test 2.2: Get field by ID
     * @param fieldId Field ID to fetch
     * @throws Exception if get operation fails
     */
    private void getConfigFieldById(Long fieldId) throws Exception {
        LOGGER.info("[Test 2.2] Getting field by ID: " + fieldId);
        
        FieldsOperations ops = new FieldsOperations();
        
        ParameterMap params = new ParameterMap();
        params.add(FieldsOperations.GetFieldParam.MODULE, currentModuleAPIName);
        
        APIResponse<com.zoho.appos.api.fields.ResponseHandler> response = 
            ops.getField(fieldId, params, null);
        logAPIResponse("Get Field by ID", response);
        
        LOGGER.info("Field fetched successfully");
    }
    
    /**
     * Test 2.3: Get all config fields
     * @throws Exception if get operation fails
     */
    private void getAllConfigFields() throws Exception {
        LOGGER.info("[Test 2.3] Getting all fields from config module...");
        
        FieldsOperations ops = new FieldsOperations();
        
        ParameterMap params = new ParameterMap();
        params.add(FieldsOperations.GetConfigFieldsParam.MODULE, currentModuleAPIName);
        
        HeaderMap headers = new HeaderMap();
        
        APIResponse<com.zoho.appos.api.fields.ResponseHandler> response = 
            ops.getConfigFields(params, headers);
        logAPIResponse("Get All Config Fields", response);
        
        if (response.getResponseJSON() instanceof JSONObject) {
            JSONObject json = (JSONObject) response.getResponseJSON();
            if (json.has("fields")) { // no i18n
                JSONArray fieldsArr = json.getJSONArray("fields"); // no i18n
                LOGGER.info("Found " + fieldsArr.length() + " fields in config module");
                
                for (int i = 0; i < fieldsArr.length(); i++) {
                    JSONObject fieldJson = fieldsArr.getJSONObject(i);
                    LOGGER.info("  " + (i+1) + ". " + fieldJson.optString("field_label") + // no i18n
                              " (" + fieldJson.optString("data_type") + ")"); // no i18n
                }
            }
        }
    }
    
    /**
     * Test 2.4: Update field properties
     * @param fieldId Field ID to update
     * @throws Exception if update operation fails
     */
    private void updateConfigField(Long fieldId) throws Exception {
        LOGGER.info("[Test 2.4] Updating field ID: " + fieldId);
        
        FieldsOperations ops = new FieldsOperations();
        com.zoho.appos.api.fields.BodyWrapper wrapper = new com.zoho.appos.api.fields.BodyWrapper();
        
        List<Fields> fields = new ArrayList<>();
        Fields field = new Fields();
        field.setId(fieldId);
        field.setFieldLabel("Updated Item Name"); // no i18n
        field.setLength(250); // Increased length
        field.setFilterable(true);
        fields.add(field);
        wrapper.setFields(fields);
        
        ParameterMap params = new ParameterMap();
        params.add(FieldsOperations.UpdateFieldParam.MODULE, currentModuleAPIName);
        
        HeaderMap headers = new HeaderMap();
        
        APIResponse<com.zoho.appos.api.fields.ActionHandler> response = 
            ops.updateField(fieldId, wrapper, params, headers);
        logAPIResponse("Update Field", response);
        
        LOGGER.info("Field updated successfully");
    }
    
    // ==================== RECORD OPERATIONS ====================
    
    /**
     * TEST SUITE 3: Config Record CRUD Operations
     * @throws Exception if record operations fail
     */
    public void testConfigRecordOperations() throws Exception {
        LOGGER.info("\n");
        LOGGER.info("  TEST SUITE 3: Config Record CRUD Operations     ");
        LOGGER.info("\n");
        
        // Test 3.1: Create Single Config Record
        currentRecordId = createSingleConfigRecord();
        if (currentRecordId == null) {
            throw new Exception("Failed to create Config record. Record ID is null.");
        }
        
        // Test 3.2: Create Multiple Config Records
        createMultipleConfigRecords();
        
        // Test 3.3: Get Config Record by ID
        getConfigRecordById(currentRecordId);
        
        // Test 3.4: Get All Config Records
        getAllConfigRecords();
        
        // Test 3.5: Update Config Record
        updateConfigRecord(currentRecordId);
        
        LOGGER.info("Record operations test suite completed\n");
    }
    
    /**
     * Test 3.1: Create single Config record
     * @return Record ID of created record
     * @throws Exception if record creation fails
     */
    private Long createSingleConfigRecord() throws Exception {
        LOGGER.info("[Test 3.1] Creating single Config record...");
        
        RecordOperations recordOps = new RecordOperations(currentModuleAPIName);
        com.zoho.appos.api.record.BodyWrapper wrapper = new com.zoho.appos.api.record.BodyWrapper();
        
        List<com.zoho.appos.api.record.Record> records = new ArrayList<>();
        com.zoho.appos.api.record.Record record = new com.zoho.appos.api.record.Record();
        
        record.addKeyValue("Name1", "Configuration Config 1"); // Mandatory field // no i18n
        record.addKeyValue("ItemName", "Config Item 1"); // no i18n
        
        records.add(record);
        wrapper.setData(records);
        
        APIResponse<com.zoho.appos.api.record.ActionHandler> response = 
            recordOps.createSettingRecords(wrapper, null);
        logAPIResponse("Create Config Record", response);
        
        Long recordId = extractRecordId(response);
        if (recordId == null) {
            throw new Exception("Could not extract record ID from response.");
        }
        
        LOGGER.info("Config record created with ID: " + recordId);
        return recordId;
    }
    
    /**
     * Test 3.2: Create multiple Config records (batch)
     * @throws Exception if batch creation fails
     */
    private void createMultipleConfigRecords() throws Exception {
        LOGGER.info("[Test 3.2] Creating multiple Config records...");
        
        RecordOperations recordOps = new RecordOperations(currentModuleAPIName);
        com.zoho.appos.api.record.BodyWrapper wrapper = new com.zoho.appos.api.record.BodyWrapper();
        
        List<com.zoho.appos.api.record.Record> records = new ArrayList<>();
        
        for (int i = 2; i <= 4; i++) {
            com.zoho.appos.api.record.Record record = new com.zoho.appos.api.record.Record();
            record.addKeyValue("Name1", "Configuration Config " + i); // Mandatory field // no i18n
            record.addKeyValue("ItemName", "Config Item " + i); // no i18n
            records.add(record);
        }
        
        wrapper.setData(records);
        
        APIResponse<com.zoho.appos.api.record.ActionHandler> response = 
            recordOps.createSettingRecords(wrapper, null);
        logAPIResponse("Create Multiple Configs", response);
        
        LOGGER.info("Multiple Config records created successfully");
    }
    
    /**
     * Test 3.3: Get Config record by ID
     * @param recordId Record ID to fetch
     * @throws Exception if get operation fails
     */
    private void getConfigRecordById(Long recordId) throws Exception {
        LOGGER.info("[Test 3.3] Getting Config record by ID: " + recordId);
        
        RecordOperations recordOps = new RecordOperations(currentModuleAPIName);
        
        ParameterMap params = new ParameterMap();
        HeaderMap headers = new HeaderMap();
        
        APIResponse<com.zoho.appos.api.record.ResponseHandler> response = 
            recordOps.getSettingRecord(recordId, params, headers);
        logAPIResponse("Get Config Record", response);
        
        if (response.getResponseJSON() instanceof JSONObject) {
            JSONObject json = (JSONObject) response.getResponseJSON();
            if (json.has("data")) { // no i18n
                JSONArray data = json.getJSONArray("data"); // no i18n
                if (data.length() > 0) {
                    JSONObject recordData = data.getJSONObject(0);
                    LOGGER.info("  - Record ID: " + recordData.opt("id")); // no i18n
                    LOGGER.info("  - Name: " + recordData.opt("Name")); // no i18n
                    LOGGER.info("  - Status: " + recordData.opt("Status")); // no i18n
                }
            }
        }
        
        LOGGER.info("Config record fetched successfully");
    }
    
    /**
     * Test 3.4: Get all Config records
     * @throws Exception if get operation fails
     */
    private void getAllConfigRecords() throws Exception {
        LOGGER.info("[Test 3.4] Getting all Config records...");
        
        RecordOperations recordOps = new RecordOperations(currentModuleAPIName);
        
        ParameterMap params = new ParameterMap();
        params.add(RecordOperations.GetRecordsParam.PAGE, 1);
        params.add(RecordOperations.GetRecordsParam.PER_PAGE, 20);
        
        HeaderMap headers = new HeaderMap();
        
        APIResponse<com.zoho.appos.api.record.ResponseHandler> response = 
            recordOps.getSettingRecords(params, headers);
        logAPIResponse("Get All Config Records", response);
        
        if (response.getResponseJSON() instanceof JSONObject) {
            JSONObject json = (JSONObject) response.getResponseJSON();
            if (json.has("data")) { // no i18n
                JSONArray data = json.getJSONArray("data"); // no i18n
                LOGGER.info("Found " + data.length() + " Config records");
                
                for (int i = 0; i < data.length(); i++) {
                    JSONObject recordJson = data.getJSONObject(i);
                    LOGGER.info("  " + (i+1) + ". " + recordJson.optString("Name") + // no i18n
                              " - " + recordJson.optString("Status")); // no i18n
                }
            }
        }
    }
    
    /**
     * Test 3.5: Update Config record
     * @param recordId Record ID to update
     * @throws Exception if update operation fails
     */
    private void updateConfigRecord(Long recordId) throws Exception {
        LOGGER.info("[Test 3.5] Updating Config record ID: " + recordId);
        
        RecordOperations recordOps = new RecordOperations(currentModuleAPIName);
        com.zoho.appos.api.record.BodyWrapper wrapper = new com.zoho.appos.api.record.BodyWrapper();
        
        List<com.zoho.appos.api.record.Record> records = new ArrayList<>();
        com.zoho.appos.api.record.Record record = new com.zoho.appos.api.record.Record();
        
        record.addKeyValue("Name", "Updated Configuration Config"); // Mandatory field // no i18n
        record.addKeyValue("ItemName", "Updated Config Item"); // no i18n
        
        records.add(record);
        wrapper.setData(records);
        
        APIResponse<com.zoho.appos.api.record.ActionHandler> response = 
            recordOps.updateSettingRecord(recordId, wrapper, null);
        logAPIResponse("Update Config Record", response);
        
        LOGGER.info("Config record updated successfully");
    }
    
    // ==================== ADVANCED OPERATIONS ====================
    
    /**
     * TEST SUITE 4: Batch operations for config modules
     * @throws Exception if batch operations fail
     */
    public void testBatchConfigOperations() throws Exception {
        LOGGER.info("\n");
        LOGGER.info("  TEST SUITE 4: Batch Config Operations           ");
        LOGGER.info("\n");
        
        testBatchFieldCreation();
        
        LOGGER.info("Batch operations test suite completed\n");
    }
    
    /**
     * Test batch field creation
     * @throws Exception if batch field creation fails
     */
    private void testBatchFieldCreation() throws Exception {
        LOGGER.info("[Test 4.1] Creating multiple fields in batch...");
        
        FieldsOperations ops = new FieldsOperations();
        com.zoho.appos.api.fields.BodyWrapper wrapper = new com.zoho.appos.api.fields.BodyWrapper();
        
        List<Fields> fields = new ArrayList<>();
        
        // Field 1: Email
        Fields emailField = new Fields();
        emailField.setFieldLabel("Email"); // no i18n
        emailField.setDataType("email"); // no i18n
        fields.add(emailField);
        
        // Field 2: Phone
        Fields phoneField = new Fields();
        phoneField.setFieldLabel("Phone"); // no i18n
        phoneField.setDataType("phone"); // no i18n
        fields.add(phoneField);
        
        // Field 3: Date
        Fields dateField = new Fields();
        dateField.setFieldLabel("EffectiveDate"); // no i18n
        dateField.setDataType("date"); // no i18n
        fields.add(dateField);
        
        wrapper.setFields(fields);
        
        ParameterMap params = new ParameterMap();
        params.add(FieldsOperations.CreateFieldParam.MODULE, currentModuleAPIName);
        
        APIResponse<com.zoho.appos.api.fields.ActionHandler> response = 
            ops.createField(wrapper, params);
        logAPIResponse("Batch Create Fields", response);
        
        LOGGER.info("Batch field creation completed (3 fields)");
    }
    
    // ==================== VALIDATION TESTS ====================
    
    /**
     * TEST SUITE 5: Validation and error handling
     * @throws Exception if validation tests fail
     */
    public void testConfigModuleValidations() throws Exception {
        LOGGER.info("\n");
        LOGGER.info("  TEST SUITE 5: Validation Tests                  ");
        LOGGER.info("\n");
        
        testInvalidModuleError();
        
        LOGGER.info("Validation test suite completed\n");
    }
    
    /**
     * Test invalid module error
     */
    private void testInvalidModuleError() {
        try {
            LOGGER.info("[Test 5.1] Testing invalid module error handling...");
            
            ModulesOperations ops = new ModulesOperations();
            APIResponse<com.zoho.appos.api.modules.ResponseHandler> response = 
                ops.getConfigModuleByAPIName("NonExistentModule12345"); // no i18n
            
            if (response != null && response.getStatusCode() == 404) {
                LOGGER.info("Invalid module error handled correctly (404)");
            } else {
                LOGGER.info("  Response status: " + (response != null ? response.getStatusCode() : "null"));
            }
            
        } catch (Exception e) {
            LOGGER.info("Invalid module exception handled (expected): " + e.getMessage());
        }
    }
    
    // ==================== CLEANUP ====================
    
    /**
     * Cleanup test data - Delete all created resources
     * Order: Records -> Fields -> Module
     * @throws Exception if cleanup fails
     */
    private void cleanup() throws Exception {
        LOGGER.info("\n");
        LOGGER.info("  Cleanup: Removing Test Data                     ");
        LOGGER.info("\n");
        
        // 1. Delete Records
        try {
            if (currentRecordId != null) {
                LOGGER.info("Cleanup 1: Deleting test records...");
                RecordOperations recordOps = new RecordOperations(currentModuleAPIName);
                
                ParameterMap params = new ParameterMap();
                params.add(RecordOperations.GetRecordsParam.PAGE, 1);
                params.add(RecordOperations.GetRecordsParam.PER_PAGE, 100);
                
                APIResponse<com.zoho.appos.api.record.ResponseHandler> listResponse = 
                    recordOps.getSettingRecords(params, new HeaderMap());
                
                if (listResponse != null && listResponse.getResponseJSON() instanceof JSONObject) {
                    JSONObject json = (JSONObject) listResponse.getResponseJSON();
                    if (json.has("data")) { // no i18n
                        JSONArray data = json.getJSONArray("data"); // no i18n
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject recordJson = data.getJSONObject(i);
                            Long recId = recordJson.optLong("id"); // no i18n
                            if (recId != null && recId > 0) {
                                recordOps.deleteSettingRecord(recId, null, null);
                                LOGGER.info("  Deleted record ID: " + recId);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting records: " + e.getMessage(), e);
        }
        
        // 2. Delete Fields
        try {
            if (currentFieldId != null) {
                LOGGER.info("Cleanup 2: Deleting test fields...");
                FieldsOperations fieldOps = new FieldsOperations();
                
                ParameterMap getParams = new ParameterMap();
                getParams.add(FieldsOperations.GetConfigFieldsParam.MODULE, currentModuleAPIName);
                
                APIResponse<com.zoho.appos.api.fields.ResponseHandler> listResponse = 
                    fieldOps.getConfigFields(getParams, new HeaderMap());
                
                if (listResponse != null && listResponse.getResponseJSON() instanceof JSONObject) {
                    JSONObject json = (JSONObject) listResponse.getResponseJSON();
                    if (json.has("fields")) { // no i18n
                        JSONArray fields = json.getJSONArray("fields"); // no i18n
                        for (int i = 0; i < fields.length(); i++) {
                            JSONObject fieldJson = fields.getJSONObject(i);
                            String fieldLabel = fieldJson.optString("field_label"); // no i18n
                            if (fieldLabel != null && 
                                (fieldLabel.equals("ItemName") || fieldLabel.equals("Updated Item Name") || // no i18n
                                 fieldLabel.equals("Email") || fieldLabel.equals("Phone") || // no i18n
                                 fieldLabel.equals("EffectiveDate"))) { // no i18n
                                
                                Long fldId = fieldJson.optLong("id"); // no i18n
                                if (fldId != null && fldId > 0) {
                                    ParameterMap deleteParams = new ParameterMap();
                                    deleteParams.add(FieldsOperations.DeleteFieldParam.MODULE, currentModuleAPIName);
                                    fieldOps.deleteField(fldId, deleteParams, new HeaderMap());
                                    LOGGER.info("  Deleted field: " + fieldLabel);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting fields: " + e.getMessage(), e);
        }
        
        // 3. Delete Module
        try {
            if (currentModuleAPIName != null) {
                LOGGER.info("Cleanup 3: Deleting test module...");
                ModulesOperations modulesOps = new ModulesOperations();
                LOGGER.info("  Note: Config module deletion may not be fully supported");
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting module: " + e.getMessage(), e);
        }
        
        LOGGER.info("Cleanup completed\n");
    }
    
    // ==================== UTILITY METHODS ====================
    
    /**
     * Log API response details and throw exception if not successful.
     */
    private void logAPIResponse(String operation, APIResponse<?> response) throws Exception {
        if (response == null) {
            String errorMsg = operation + ": Response is null";
            LOGGER.severe(errorMsg);
            throw new Exception(errorMsg);
        }
        
        int statusCode = response.getStatusCode();
        boolean isSuccess = statusCode >= 200 && statusCode < 300;
        
        LOGGER.info(String.format(
            "  [%s] Status: %d",
            operation,
            statusCode
        ));
        
        if (response.getObject() != null) {
            LOGGER.info("  Response Object: " + response.getObject().getClass().getSimpleName());
        }
        
        if (response.getResponseJSON() != null) {
            LOGGER.fine("  Response JSON: " + response.getResponseJSON().toString());
        }
        
        if (!isSuccess) {
            String errorMsg = String.format(
                "%s failed with status code: %d. Response: %s",
                operation,
                statusCode,
                response.getResponseJSON() != null ? response.getResponseJSON().toString() : "No response body" // no i18n
            );
            LOGGER.severe(errorMsg);
            throw new Exception(errorMsg);
        }
        
        LOGGER.info("  " + operation + ": Success");
    }
    
    /**
     * Extract field ID from response
     */
    private Long extractFieldId(APIResponse<?> response) {
        try {
            if (response != null && response.getResponseJSON() instanceof JSONObject) {
                JSONObject json = (JSONObject) response.getResponseJSON();
                JSONArray fieldsArr = json.getJSONArray("fields"); // no i18n
                JSONObject details = fieldsArr.getJSONObject(0).getJSONObject("details"); // no i18n
                return details.getLong("id"); // no i18n
            }
        } catch (Exception e) {
            LOGGER.warning("  Could not extract field ID: " + e.getMessage());
        }
        return null;
    }
    
    /**
     * Extract record ID from response
     */
    private Long extractRecordId(APIResponse<?> response) {
        try {
            if (response != null && response.getResponseJSON() instanceof JSONObject) {
                JSONObject json = (JSONObject) response.getResponseJSON();
                JSONArray dataArr = json.getJSONArray("data"); // no i18n
                JSONObject details = dataArr.getJSONObject(0).getJSONObject("details"); // no i18n
                return details.getLong("id"); // no i18n
            }
        } catch (Exception e) {
            LOGGER.warning("  Could not extract record ID: " + e.getMessage());
        }
        return null;
    }
    
    /**
     * Fetches the Standard Profile ID dynamically via API.
     */
    private Long getStandardProfileId() throws Exception {
        if (cachedStandardProfileId != null) {
            return cachedStandardProfileId;
        }
        
        try {
            LOGGER.info("Fetching profiles to get Standard Profile ID...");
            ProfilesOperations profilesOps = new ProfilesOperations();
            
            APIResponse<com.zoho.appos.api.profiles.ResponseHandler> response = 
                profilesOps.getProfiles(new ParameterMap(), new HeaderMap());
            
            if (response != null && response.isExpected()) {
                com.zoho.appos.api.profiles.ResponseHandler responseHandler = response.getObject();
                
                if (responseHandler instanceof ResponseWrapper) {
                    ResponseWrapper responseWrapper = (ResponseWrapper) responseHandler;
                    List<Profile> profiles = responseWrapper.getProfiles();
                    
                    if (profiles != null && !profiles.isEmpty()) {
                        for (Profile profile : profiles) {
                            String profileName = profile.getName();
                            if (profileName != null && 
                                (profileName.equalsIgnoreCase("Standard") || // no i18n
                                 profileName.equalsIgnoreCase("Administrator") || // no i18n
                                 profileName.equalsIgnoreCase("Admin"))) { // no i18n
                                cachedStandardProfileId = profile.getId();
                                LOGGER.info("Found profile: " + profileName + " with ID: " + cachedStandardProfileId);
                                return cachedStandardProfileId;
                            }
                        }
                        
                        Profile firstProfile = profiles.get(0);
                        cachedStandardProfileId = firstProfile.getId();
                        LOGGER.info("Using first available profile: " + firstProfile.getName() + 
                                   " with ID: " + cachedStandardProfileId);
                        return cachedStandardProfileId;
                    }
                }
            }
            
            throw new Exception("Could not fetch profiles from API - response was empty or invalid");
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error fetching profile ID", e);
            throw e;
        }
    }
    
    /**
     * Main method to run tests
     */
    public static void main(String[] args) {
        ConfigModuleCRUDTest test = new ConfigModuleCRUDTest();
        try {
            test.runAllConfigTests();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Test execution failed with exception", e);
            System.exit(1);
        }
    }
}
