//$Id$
package com.zoho.ctv.test;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.zoho.appos.api.HeaderMap;
import com.zoho.appos.api.ParameterMap;
import com.zoho.appos.api.fields.Fields;
import com.zoho.appos.api.fields.FieldsOperations;
import com.zoho.appos.api.modules.ActionHandler;
import com.zoho.appos.api.modules.Modules;
import com.zoho.appos.api.modules.ModulesOperations;
import com.zoho.appos.api.profiles.MinifiedProfile;
import com.zoho.appos.api.record.RecordOperations;
import com.zoho.appos.api.util.APIResponse;

public class ConfigModuleTest {

    private static final Logger LOGGER = Logger.getLogger(ConfigModuleTest.class.getName());
    private static final String MODULE_API_NAME = "ConfigRoleLifecycle";// No I18N
    private static final Long PROFILEID = 111116000000000497L;

    public void startTest() {
        try {
            LOGGER.info("=== Starting Config Module Lifecycle Test ===");

            //Create Module
            createConfigModule();

            //Get Module
            getConfigModule();

            //Create Field
            Long fieldId = createConfigField();
            if (fieldId != null) {
                getConfigField(fieldId);
                updateConfigField(fieldId);
            }

            //Create Record
            Long recordId = createConfigRecord();
            if (recordId != null) {
                getConfigRecord(recordId);// Issue fix inprogress
                updateConfigRecord(recordId);
                deleteConfigRecord(recordId);
            }

            //Delete Field
            if (fieldId != null) {
                deleteConfigField(fieldId);
            }

            //Delete Module
            deleteConfigModule(); // Not supported yet

            LOGGER.info("=== Config Module Lifecycle Test Completed Successfully ===");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in startTest()", e);
        }
    }

    // ---------------- MODULE OPERATIONS ----------------

    public void createConfigModule() {
        try {
            LOGGER.info("Creating Config Module: " + MODULE_API_NAME);
            ModulesOperations modulesOps = new ModulesOperations();
            com.zoho.appos.api.modules.BodyWrapper wrapper = new com.zoho.appos.api.modules.BodyWrapper();
            List<Modules> modules = new ArrayList();
            Modules module = new Modules();
            module.setAPIName(MODULE_API_NAME);
            module.setPluralLabel("Config Roles");// No I18N
            module.setSingularLabel("Config Role");// No I18N
            module.setCategory("configuration");// No I18N
            module.setAuthType("self");// No I18N

            JSONObject displayField = new JSONObject();
            displayField.put("field_label", "ConfigRoleName");
            displayField.put("data_type", "text");
            module.setDisplayField(displayField);

            List<MinifiedProfile> profiles = new ArrayList<>();
            MinifiedProfile profile = new MinifiedProfile();
            profile.setId(PROFILEID);
            profiles.add(profile);
            module.setProfiles(profiles);
            modules.add(module);
            wrapper.setModules(modules);

            APIResponse<ActionHandler> response = modulesOps.createConfigModules(wrapper);
            logResponse("Create Module", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in createConfigModule()", e);
        }
    }

    public void getConfigModule() {
        try {
            LOGGER.info("Fetching Config Module details...");
            ModulesOperations ops = new ModulesOperations();
            APIResponse<com.zoho.appos.api.modules.ResponseHandler> response = ops
                    .getConfigModuleByAPIName(MODULE_API_NAME);
            logResponse("Get Module", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in getConfigModule()", e);
        }
    }

    public void deleteConfigModule() {
        try {
            LOGGER.info("Deleting Config Module: " + MODULE_API_NAME);
            ModulesOperations ops = new ModulesOperations();
            APIResponse<ActionHandler> response = ops.deleteModuleByAPIName(MODULE_API_NAME,null);
            logResponse("Delete Module", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in deleteConfigModule()", e);
        }
    }

    // ---------------- FIELD OPERATIONS ----------------

    public Long createConfigField() {
        try {
            LOGGER.info("Creating Field in module: " + MODULE_API_NAME);
            FieldsOperations ops = new FieldsOperations();
            com.zoho.appos.api.fields.BodyWrapper wrapper = new com.zoho.appos.api.fields.BodyWrapper();
            List<Fields> fields = new ArrayList();
            Fields field = new Fields();
            field.setFieldLabel("ConfigRoleName");// No I18N
            field.setDataType("text");// No I18N
            field.setLength(150);
            field.setFilterable(true);
            fields.add(field);
            wrapper.setFields(fields);

            ParameterMap param = new ParameterMap() {{
                add(FieldsOperations.CreateFieldParam.MODULE, MODULE_API_NAME);
            }};

            APIResponse<com.zoho.appos.api.fields.ActionHandler> response = ops.createField(wrapper, param);
            logResponse("Create Field", response);// No I18N

            // Extract Field ID
            if (response != null && response.getResponseJSON() instanceof JSONObject) {
            	try {
            		JSONObject json = (JSONObject) response.getResponseJSON();             
                    JSONArray dataArr = json.getJSONArray("fields");// No I18N
                    JSONObject details = dataArr.getJSONObject(0).getJSONObject("details");
                    long fieldId = details.getLong("id");// No I18N
                    LOGGER.log(Level.INFO, "Field created successfully. Field ID: {0}", fieldId);
                    return fieldId;
                } catch (Exception ex) {
                    LOGGER.warning("Could not extract Field ID: " + ex.getMessage());
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in createConfigField()", e);
        }
        return null;
    }

    public void getConfigField(long fieldId) {
        try {
            LOGGER.info("Fetching Field with ID: " + fieldId);
            FieldsOperations ops = new FieldsOperations();
            ParameterMap params = new ParameterMap() {{
                add(FieldsOperations.GetFieldParam.MODULE, MODULE_API_NAME);
            }};
            APIResponse<com.zoho.appos.api.fields.ResponseHandler> response = ops.getField(fieldId, params, null);
            logResponse("Get Field", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in getConfigField()", e);
        }
    }

    public void updateConfigField(long fieldId) {
        try {
            LOGGER.info("Updating Field ID: " + fieldId);
            FieldsOperations ops = new FieldsOperations();
            com.zoho.appos.api.fields.BodyWrapper wrapper = new com.zoho.appos.api.fields.BodyWrapper();
            List<Fields> fields = new ArrayList();
            Fields field = new Fields();
            field.setId(fieldId);
            field.setFieldLabel("Updated ConfigRoleName");// No I18N
            field.setLength(200);
            field.setFilterable(true);
            fields.add(field);
            wrapper.setFields(fields);

            ParameterMap params = new ParameterMap() {{
                add(FieldsOperations.UpdateFieldParam.MODULE, MODULE_API_NAME);
            }};
            HeaderMap headerInstance = new HeaderMap();
            APIResponse<com.zoho.appos.api.fields.ActionHandler> response = ops.updateField(fieldId, wrapper, params,headerInstance);
            logResponse("Update Field", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in updateConfigField()", e);
        }
    }

    public void deleteConfigField(long fieldId) {
        try {
            LOGGER.info("Deleting Field ID: " + fieldId);
            FieldsOperations ops = new FieldsOperations();
            ParameterMap params = new ParameterMap() {{
                add(FieldsOperations.DeleteFieldParam.MODULE, MODULE_API_NAME);
            }};
            HeaderMap headerInstance = new HeaderMap();
            APIResponse<com.zoho.appos.api.fields.ActionHandler> response = ops.deleteField(fieldId, params,headerInstance);
            logResponse("Delete Field", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in deleteConfigField()", e);
        }
    }

    // ---------------- RECORD OPERATIONS ----------------

    public Long createConfigRecord() {
        try {
            LOGGER.info("Creating Record in module: " + MODULE_API_NAME);
            RecordOperations recordOps = new RecordOperations(MODULE_API_NAME);
            com.zoho.appos.api.record.BodyWrapper wrapper = new com.zoho.appos.api.record.BodyWrapper();
            List<com.zoho.appos.api.record.Record> records = new ArrayList<>();
            com.zoho.appos.api.record.Record record = new com.zoho.appos.api.record.Record();
            record.addKeyValue("ConfigRoleName", "Administrator Role");// No I18N
            records.add(record);
            wrapper.setData(records);

            APIResponse<com.zoho.appos.api.record.ActionHandler> response = recordOps.createSettingRecords(wrapper, null);
            logResponse("Create Record", response);// No I18N

            if (response != null && response.getResponseJSON() instanceof JSONObject) {
                JSONObject json = (JSONObject) response.getResponseJSON();
                try {
                    JSONArray dataArr = json.getJSONArray("data");// No I18N
                    JSONObject details = dataArr.getJSONObject(0).getJSONObject("details");
                    long recordId = details.getLong("id");// No I18N
                    LOGGER.log(Level.INFO, "Record created successfully. Record ID: {0}", recordId);
                    return recordId;
                } catch (Exception ex) {
                    LOGGER.warning("Could not extract Record ID: " + ex.getMessage());
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in createConfigRecord()", e);
        }
        return null;
    }

    public void getConfigRecord(long recordId) {
        try {
            LOGGER.info("Fetching Record ID: " + recordId);
            RecordOperations recordOps = new RecordOperations(MODULE_API_NAME);
            APIResponse<com.zoho.appos.api.record.ResponseHandler> response =
                    recordOps.getSettingRecord(recordId, new ParameterMap(), null);
            logResponse("Get Record", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in getConfigRecord()", e);
        }
    }

    public void updateConfigRecord(long recordId) {
        try {
            LOGGER.info("Updating Record ID: " + recordId);
            RecordOperations recordOps = new RecordOperations(MODULE_API_NAME);
            com.zoho.appos.api.record.BodyWrapper wrapper = new com.zoho.appos.api.record.BodyWrapper();
            List<com.zoho.appos.api.record.Record> records = new ArrayList<>();
            com.zoho.appos.api.record.Record record = new com.zoho.appos.api.record.Record();
            record.addKeyValue("ConfigRoleName", "Updated Administrator Role");// No I18N
            records.add(record);
            wrapper.setData(records);

            APIResponse<com.zoho.appos.api.record.ActionHandler> response =
                    recordOps.updateSettingRecord(recordId, wrapper, null);
            logResponse("Update Record", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in updateConfigRecord()", e);
        }
    }

    public void deleteConfigRecord(long recordId) {
        try {
            LOGGER.info("Deleting Record ID: " + recordId);
            RecordOperations recordOps = new RecordOperations(MODULE_API_NAME);
            APIResponse<com.zoho.appos.api.record.ActionHandler> response =
                    recordOps.deleteSettingRecord(recordId, null, null);
            logResponse("Delete Record", response);// No I18N
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception in deleteConfigRecord()", e);
        }
    }

    // ---------------- LOGGER HELPER ----------------

    private void logResponse(String action, APIResponse<?> response) {
        if (response == null) {
            LOGGER.warning(action + " failed: null response");
            return;
        }

        int statusCode = response.getStatusCode();
        LOGGER.info("[" + action + "] Status Code: " + statusCode);

        if (statusCode >= 200 && statusCode < 400) {
            LOGGER.info(action + " Success: " + response.getResponseJSON());
        } else {
            LOGGER.warning(action + " Failed: " + response.getResponseJSON());
        }
    }
}
