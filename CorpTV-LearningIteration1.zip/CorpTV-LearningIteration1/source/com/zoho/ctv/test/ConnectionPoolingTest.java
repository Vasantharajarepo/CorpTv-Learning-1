//$Id$
package com.zoho.ctv.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.appos.api.HeaderMap;
import com.zoho.appos.api.ParameterMap;
import com.zoho.appos.api.modules.ModulesOperations;
import com.zoho.appos.api.profiles.ProfilesOperations;
import com.zoho.appos.api.roles.RolesOperations;
import com.zoho.appos.api.util.APIResponse;

/**
 * Comprehensive test suite for Connection Pooling in AppOS SDK
 * 
 * NEW FEATURES IN SDK (Mar 13, 2026):
 * ============================================
 * 
 * CONNECTION POOLING TESTS:
 * - testBasicConnection() - Verify single API call works correctly
 * - testConcurrentRequests() - Simulate multiple threads making API calls
 * - testSequentialRapidRequests() - Test connection reuse with rapid requests
 * - testMixedAPIOperations() - Test pooling with different API types
 * - testBurstRequests() - Test pool behavior under sudden high load
 * - testLongRunningConcurrent() - Test pool stability over extended periods
 * 
 * USAGE:
 * <pre>
 * ConnectionPoolingTest test = new ConnectionPoolingTest();
 * test.runAllConnectionPoolingTests(); // Run complete test suite
 * 
 * // Or run individual test suites:
 * test.testBasicConnectionOperations();
 * test.testConcurrencyOperations();
 * test.testStressOperations();
 * </pre>
 * 
 * @author AppOS SDK Team
 * @version 1.0
 * @since SDK v18.0.0
 */
public class ConnectionPoolingTest {

    private static final Logger LOGGER = Logger.getLogger(ConnectionPoolingTest.class.getName());
    
    // Test Configuration
    private static final int CONCURRENT_THREADS = 10;
    private static final int THREAD_POOL_SIZE = 20;
    private static final long TEST_TIMEOUT_SECONDS = 120;
    
    // Test Metrics Storage
    private AtomicInteger successCount = new AtomicInteger(0);
    private AtomicInteger failureCount = new AtomicInteger(0);
    private AtomicInteger timeoutCount = new AtomicInteger(0);
    
    /**
     * Run complete Connection Pooling test suite
     * Tests all operations in proper sequence
     * @throws Exception if any test fails
     */
    public void runAllConnectionPoolingTests() throws Exception {
        LOGGER.info("====================================================="); // no i18n
        LOGGER.info("    Connection Pooling Test Suite - SDK v18.0.0      "); // no i18n
        LOGGER.info("=====================================================\n"); // no i18n
        
        try {
            // Reset counters
            resetCounters();
            
            // Phase 1: Basic Connection Operations
            testBasicConnectionOperations();
            
            // Phase 2: Concurrency Operations
            testConcurrencyOperations();
            
            // Phase 3: Stress Operations
            testStressOperations();
            
            // Phase 4: Summary
            logTestSummary();
            
            LOGGER.info("\n====================================================="); // no i18n
            LOGGER.info("    All Connection Pooling Tests Completed!          "); // no i18n
            LOGGER.info("====================================================="); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Connection pooling test suite failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== BASIC CONNECTION OPERATIONS ====================
    
    /**
     * TEST SUITE 1: Basic Connection Operations
     * 
     * Tests:
     * 1.1 Single API call verification
     * 1.2 Sequential rapid requests for connection reuse
     * @throws Exception if basic connection operations fail
     */
    public void testBasicConnectionOperations() throws Exception {
        LOGGER.info("\n"); // no i18n
        LOGGER.info("  TEST SUITE 1: Basic Connection Operations        "); // no i18n
        LOGGER.info("\n"); // no i18n
        
        // Test 1.1: Single API Call Test
        testBasicConnection();
        
        // Test 1.2: Sequential Rapid Requests
        testSequentialRapidRequests();
        
        LOGGER.info("Basic connection operations test suite completed\n"); // no i18n
    }
    
    /**
     * Test 1.1: Basic Connection Test
     * Verifies that a single API call works correctly
     * @throws Exception if connection test fails
     */
    private void testBasicConnection() throws Exception {
        LOGGER.info("[Test 1.1] Testing basic connection..."); // no i18n
        
        long startTime = System.currentTimeMillis();
        
        ProfilesOperations profilesOps = new ProfilesOperations();
        APIResponse<?> response = profilesOps.getProfiles(new ParameterMap(), new HeaderMap());
        
        long duration = System.currentTimeMillis() - startTime;
        
        if (response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
            successCount.incrementAndGet();
            LOGGER.info("  - Status: PASSED"); // no i18n
            LOGGER.info("  - Response Code: " + response.getStatusCode()); // no i18n
            LOGGER.info("  - Duration: " + duration + "ms"); // no i18n
        } else {
            failureCount.incrementAndGet();
            throw new Exception("Basic connection test failed. Response code: " + // no i18n
                (response != null ? response.getStatusCode() : "null")); // no i18n
        }
        
        LOGGER.info("Basic connection test completed successfully\n"); // no i18n
    }
    
    /**
     * Test 1.2: Sequential Rapid Requests Test
     * Makes multiple rapid sequential API calls to test connection reuse
     * @throws Exception if sequential requests fail
     */
    private void testSequentialRapidRequests() throws Exception {
        LOGGER.info("[Test 1.2] Testing sequential rapid requests..."); // no i18n
        
        int requestCount = 20;
        int passed = 0;
        int failed = 0;
        long totalDuration = 0;
        
        long testStartTime = System.currentTimeMillis();
        
        for (int i = 0; i < requestCount; i++) {
            long requestStart = System.currentTimeMillis();
            
            RolesOperations rolesOps = new RolesOperations();
            APIResponse<?> response = rolesOps.getRoles();
            
            long requestDuration = System.currentTimeMillis() - requestStart;
            totalDuration += requestDuration;
            
            if (response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
                passed++;
                successCount.incrementAndGet();
            } else {
                failed++;
                failureCount.incrementAndGet();
            }
        }
        
        long testDuration = System.currentTimeMillis() - testStartTime;
        
        LOGGER.info("  - Request Count: " + requestCount); // no i18n
        LOGGER.info("  - Passed: " + passed); // no i18n
        LOGGER.info("  - Failed: " + failed); // no i18n
        LOGGER.info("  - Total Duration: " + testDuration + "ms"); // no i18n
        LOGGER.info("  - Avg Request Time: " + (totalDuration / requestCount) + "ms"); // no i18n
        LOGGER.info("  - Requests/Second: " + String.format("%.2f", (requestCount * 1000.0) / testDuration)); // no i18n
        
        if (failed > 0) {
            throw new Exception("Sequential rapid requests test failed. Failed: " + failed); // no i18n
        }
        
        LOGGER.info("Sequential rapid requests test completed successfully\n"); // no i18n
    }
    
    // ==================== CONCURRENCY OPERATIONS ====================
    
    /**
     * TEST SUITE 2: Concurrency Operations
     * 
     * Tests:
     * 2.1 Concurrent requests from multiple threads
     * 2.2 Mixed API operations concurrently
     * @throws Exception if concurrency operations fail
     */
    public void testConcurrencyOperations() throws Exception {
        LOGGER.info("\n"); // no i18n
        LOGGER.info("  TEST SUITE 2: Concurrency Operations             "); // no i18n
        LOGGER.info("\n"); // no i18n
        
        // Test 2.1: Concurrent Requests
        testConcurrentRequests();
        
        // Test 2.2: Mixed API Operations
        testMixedAPIOperations();
        
        LOGGER.info("Concurrency operations test suite completed\n"); // no i18n
    }
    
    /**
     * Test 2.1: Concurrent Requests Test
     * Simulates multiple threads making API calls simultaneously
     * @throws Exception if concurrent requests fail
     */
    private void testConcurrentRequests() throws Exception {
        LOGGER.info("[Test 2.1] Testing concurrent requests..."); // no i18n
        
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch completionLatch = new CountDownLatch(CONCURRENT_THREADS);
        
        List<Future<RequestResult>> futures = new ArrayList<>();
        long testStartTime = System.currentTimeMillis();
        
        try {
            // Submit concurrent tasks
            for (int i = 0; i < CONCURRENT_THREADS; i++) {
                final int threadId = i;
                Future<RequestResult> future = executor.submit(() -> {
                    try {
                        startLatch.await();
                        
                        long threadStartTime = System.currentTimeMillis();
                        ProfilesOperations profilesOps = new ProfilesOperations();
                        APIResponse<?> response = profilesOps.getProfiles(new ParameterMap(), new HeaderMap());
                        long duration = System.currentTimeMillis() - threadStartTime;
                        
                        return new RequestResult(threadId, 
                            response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300, 
                            duration, 
                            response != null ? response.getStatusCode() : 0);
                    } catch (Exception e) {
                        return new RequestResult(threadId, false, 0, -1, e.getMessage());
                    } finally {
                        completionLatch.countDown();
                    }
                });
                futures.add(future);
            }
            
            // Start all threads simultaneously
            startLatch.countDown();
            
            // Wait for completion with timeout
            boolean completed = completionLatch.await(TEST_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            long totalDuration = System.currentTimeMillis() - testStartTime;
            
            // Collect results
            int passed = 0;
            int failed = 0;
            long totalRequestTime = 0;
            
            for (Future<RequestResult> future : futures) {
                try {
                    RequestResult reqResult = future.get(5, TimeUnit.SECONDS);
                    if (reqResult.success) {
                        passed++;
                        successCount.incrementAndGet();
                    } else {
                        failed++;
                        failureCount.incrementAndGet();
                    }
                    totalRequestTime += reqResult.duration;
                } catch (Exception e) {
                    failed++;
                    failureCount.incrementAndGet();
                }
            }
            
            LOGGER.info("  - Threads: " + CONCURRENT_THREADS); // no i18n
            LOGGER.info("  - Passed: " + passed); // no i18n
            LOGGER.info("  - Failed: " + failed); // no i18n
            LOGGER.info("  - Total Duration: " + totalDuration + "ms"); // no i18n
            LOGGER.info("  - Avg Request Time: " + (passed > 0 ? totalRequestTime / passed : 0) + "ms"); // no i18n
            
            if (!completed) {
                timeoutCount.incrementAndGet();
                LOGGER.warning("  - WARNING: Test timed out"); // no i18n
            }
            
            if (failed > 0) {
                throw new Exception("Concurrent requests test failed. Failed: " + failed); // no i18n
            }
            
        } finally {
            executor.shutdownNow();
        }
        
        LOGGER.info("Concurrent requests test completed successfully\n"); // no i18n
    }
    
    /**
     * Test 2.2: Mixed API Operations Test
     * Tests connection pooling with different types of API operations
     * @throws Exception if mixed API operations fail
     */
    private void testMixedAPIOperations() throws Exception {
        LOGGER.info("[Test 2.2] Testing mixed API operations..."); // no i18n
        
        ExecutorService executor = Executors.newFixedThreadPool(10);
        List<Future<RequestResult>> futures = new ArrayList<>();
        
        long testStartTime = System.currentTimeMillis();
        
        try {
            // Profiles API calls
            for (int i = 0; i < 3; i++) {
                final int id = i;
                futures.add(executor.submit(() -> {
                    long start = System.currentTimeMillis();
                    try {
                        ProfilesOperations ops = new ProfilesOperations();
                        APIResponse<?> response = ops.getProfiles(new ParameterMap(), new HeaderMap());
                        return new RequestResult(id, 
                            response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300, 
                            System.currentTimeMillis() - start, 
                            response != null ? response.getStatusCode() : 0);
                    } catch (Exception e) {
                        return new RequestResult(id, false, System.currentTimeMillis() - start, -1, e.getMessage());
                    }
                }));
            }
            
            // Roles API calls
            for (int i = 0; i < 3; i++) {
                final int id = i + 3;
                futures.add(executor.submit(() -> {
                    long start = System.currentTimeMillis();
                    try {
                        RolesOperations ops = new RolesOperations();
                        APIResponse<?> response = ops.getRoles();
                        return new RequestResult(id, 
                            response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300, 
                            System.currentTimeMillis() - start, 
                            response != null ? response.getStatusCode() : 0);
                    } catch (Exception e) {
                        return new RequestResult(id, false, System.currentTimeMillis() - start, -1, e.getMessage());
                    }
                }));
            }
            
            // Modules API calls
            for (int i = 0; i < 3; i++) {
                final int id = i + 6;
                futures.add(executor.submit(() -> {
                    long start = System.currentTimeMillis();
                    try {
                        ModulesOperations ops = new ModulesOperations();
                        APIResponse<?> response = ops.getModules(null, new HeaderMap());
                        return new RequestResult(id, 
                            response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300, 
                            System.currentTimeMillis() - start, 
                            response != null ? response.getStatusCode() : 0);
                    } catch (Exception e) {
                        return new RequestResult(id, false, System.currentTimeMillis() - start, -1, e.getMessage());
                    }
                }));
            }
            
            // Collect results
            int passed = 0;
            int failed = 0;
            long totalRequestTime = 0;
            
            for (Future<RequestResult> future : futures) {
                try {
                    RequestResult reqResult = future.get(30, TimeUnit.SECONDS);
                    if (reqResult.success) {
                        passed++;
                        successCount.incrementAndGet();
                    } else {
                        failed++;
                        failureCount.incrementAndGet();
                        LOGGER.warning("Mixed API test failed: " + reqResult.errorMessage); // no i18n
                    }
                    totalRequestTime += reqResult.duration;
                } catch (Exception e) {
                    failed++;
                    failureCount.incrementAndGet();
                }
            }
            
            long testDuration = System.currentTimeMillis() - testStartTime;
            
            LOGGER.info("  - API Types Tested: Profiles, Roles, Modules"); // no i18n
            LOGGER.info("  - Total Requests: " + futures.size()); // no i18n
            LOGGER.info("  - Passed: " + passed); // no i18n
            LOGGER.info("  - Failed: " + failed); // no i18n
            LOGGER.info("  - Total Duration: " + testDuration + "ms"); // no i18n
            LOGGER.info("  - Avg Request Time: " + (passed > 0 ? totalRequestTime / passed : 0) + "ms"); // no i18n
            
            if (failed > 0) {
                throw new Exception("Mixed API operations test failed. Failed: " + failed); // no i18n
            }
            
        } finally {
            executor.shutdownNow();
        }
        
        LOGGER.info("Mixed API operations test completed successfully\n"); // no i18n
    }
    
    // ==================== STRESS OPERATIONS ====================
    
    /**
     * TEST SUITE 3: Stress Operations
     * 
     * Tests:
     * 3.1 Burst requests under high load
     * 3.2 Long running concurrent requests
     * @throws Exception if stress operations fail
     */
    public void testStressOperations() throws Exception {
        LOGGER.info("\n"); // no i18n
        LOGGER.info("  TEST SUITE 3: Stress Operations                  "); // no i18n
        LOGGER.info("\n"); // no i18n
        
        // Test 3.1: Burst Requests
        testBurstRequests();
        
        // Test 3.2: Long Running Concurrent
        testLongRunningConcurrent();
        
        LOGGER.info("Stress operations test suite completed\n"); // no i18n
    }
    
    /**
     * Test 3.1: Burst Request Test
     * Sends a large burst of requests simultaneously to test pool behavior under stress
     * @throws Exception if burst requests fail
     */
    private void testBurstRequests() throws Exception {
        LOGGER.info("[Test 3.1] Testing burst requests..."); // no i18n
        
        int burstSize = 25;
        ExecutorService executor = Executors.newFixedThreadPool(burstSize);
        CountDownLatch startLatch = new CountDownLatch(1);
        List<Future<RequestResult>> futures = new ArrayList<>();
        
        long testStartTime = System.currentTimeMillis();
        
        try {
            // Prepare all tasks
            for (int i = 0; i < burstSize; i++) {
                final int id = i;
                futures.add(executor.submit(() -> {
                    try {
                        startLatch.await();
                        long start = System.currentTimeMillis();
                        ProfilesOperations ops = new ProfilesOperations();
                        APIResponse<?> response = ops.getProfiles(new ParameterMap(), new HeaderMap());
                        return new RequestResult(id, 
                            response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300, 
                            System.currentTimeMillis() - start, 
                            response != null ? response.getStatusCode() : 0);
                    } catch (Exception e) {
                        return new RequestResult(id, false, 0, -1, e.getMessage());
                    }
                }));
            }
            
            // Trigger burst
            startLatch.countDown();
            
            // Collect results
            int passed = 0;
            int failed = 0;
            long maxDuration = 0;
            long minDuration = Long.MAX_VALUE;
            long totalDuration = 0;
            
            for (Future<RequestResult> future : futures) {
                try {
                    RequestResult reqResult = future.get(60, TimeUnit.SECONDS);
                    if (reqResult.success) {
                        passed++;
                        successCount.incrementAndGet();
                        maxDuration = Math.max(maxDuration, reqResult.duration);
                        minDuration = Math.min(minDuration, reqResult.duration);
                        totalDuration += reqResult.duration;
                    } else {
                        failed++;
                        failureCount.incrementAndGet();
                    }
                } catch (Exception e) {
                    failed++;
                    failureCount.incrementAndGet();
                    timeoutCount.incrementAndGet();
                }
            }
            
            long testDuration = System.currentTimeMillis() - testStartTime;
            
            LOGGER.info("  - Burst Size: " + burstSize); // no i18n
            LOGGER.info("  - Passed: " + passed); // no i18n
            LOGGER.info("  - Failed: " + failed); // no i18n
            LOGGER.info("  - Total Duration: " + testDuration + "ms"); // no i18n
            LOGGER.info("  - Min Request Time: " + (minDuration == Long.MAX_VALUE ? 0 : minDuration) + "ms"); // no i18n
            LOGGER.info("  - Max Request Time: " + maxDuration + "ms"); // no i18n
            LOGGER.info("  - Avg Request Time: " + (passed > 0 ? totalDuration / passed : 0) + "ms"); // no i18n
            
            if (failed > 0) {
                throw new Exception("Burst requests test failed. Failed: " + failed); // no i18n
            }
            
        } finally {
            executor.shutdownNow();
        }
        
        LOGGER.info("Burst requests test completed successfully\n"); // no i18n
    }
    
    /**
     * Test 3.2: Long Running Concurrent Test
     * Runs concurrent requests over an extended period to test connection pool stability
     * @throws Exception if long running concurrent test fails
     */
    private void testLongRunningConcurrent() throws Exception {
        LOGGER.info("[Test 3.2] Testing long running concurrent requests..."); // no i18n
        
        int threadCount = 5;
        int iterationsPerThread = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        List<Future<ThreadResult>> futures = new ArrayList<>();
        
        long testStartTime = System.currentTimeMillis();
        
        try {
            for (int t = 0; t < threadCount; t++) {
                final int threadId = t;
                futures.add(executor.submit(() -> {
                    int threadPassed = 0;
                    int threadFailed = 0;
                    long threadTotalTime = 0;
                    
                    for (int i = 0; i < iterationsPerThread; i++) {
                        try {
                            long start = System.currentTimeMillis();
                            ProfilesOperations ops = new ProfilesOperations();
                            APIResponse<?> response = ops.getProfiles(new ParameterMap(), new HeaderMap());
                            long duration = System.currentTimeMillis() - start;
                            
                            if (response != null && response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
                                threadPassed++;
                                threadTotalTime += duration;
                            } else {
                                threadFailed++;
                            }
                            
                            // Small delay between requests
                            Thread.sleep(100);
                            
                        } catch (Exception e) {
                            threadFailed++;
                        }
                    }
                    
                    return new ThreadResult(threadId, threadPassed, threadFailed, threadTotalTime);
                }));
            }
            
            // Collect thread results
            int totalPassed = 0;
            int totalFailed = 0;
            long totalRequestTime = 0;
            
            for (Future<ThreadResult> future : futures) {
                try {
                    ThreadResult threadResult = future.get(120, TimeUnit.SECONDS);
                    totalPassed += threadResult.passed;
                    totalFailed += threadResult.failed;
                    totalRequestTime += threadResult.totalTime;
                    successCount.addAndGet(threadResult.passed);
                    failureCount.addAndGet(threadResult.failed);
                } catch (Exception e) {
                    totalFailed += iterationsPerThread;
                    failureCount.addAndGet(iterationsPerThread);
                }
            }
            
            long testDuration = System.currentTimeMillis() - testStartTime;
            int totalRequests = threadCount * iterationsPerThread;
            
            LOGGER.info("  - Threads: " + threadCount); // no i18n
            LOGGER.info("  - Iterations/Thread: " + iterationsPerThread); // no i18n
            LOGGER.info("  - Total Requests: " + totalRequests); // no i18n
            LOGGER.info("  - Passed: " + totalPassed); // no i18n
            LOGGER.info("  - Failed: " + totalFailed); // no i18n
            LOGGER.info("  - Total Duration: " + testDuration + "ms"); // no i18n
            LOGGER.info("  - Avg Request Time: " + (totalPassed > 0 ? totalRequestTime / totalPassed : 0) + "ms"); // no i18n
            LOGGER.info("  - Success Rate: " + String.format("%.2f", (totalPassed * 100.0) / totalRequests) + "%"); // no i18n
            
            if (totalFailed > 0) {
                throw new Exception("Long running concurrent test failed. Failed: " + totalFailed); // no i18n
            }
            
        } finally {
            executor.shutdownNow();
        }
        
        LOGGER.info("Long running concurrent test completed successfully\n"); // no i18n
    }
    
    // ==================== UTILITY METHODS ====================
    
    /**
     * Reset all test counters
     * @throws Exception if reset fails
     */
    private void resetCounters() throws Exception {
        successCount.set(0);
        failureCount.set(0);
        timeoutCount.set(0);
        LOGGER.info("Test counters reset"); // no i18n
    }
    
    /**
     * Log test summary with overall results
     */
    private void logTestSummary() {
        LOGGER.info("\n"); // no i18n
        LOGGER.info("  TEST SUMMARY                                     "); // no i18n
        LOGGER.info("\n"); // no i18n
        LOGGER.info("  Total Successes: " + successCount.get()); // no i18n
        LOGGER.info("  Total Failures: " + failureCount.get()); // no i18n
        LOGGER.info("  Total Timeouts: " + timeoutCount.get()); // no i18n
        LOGGER.info("  Overall Status: " + (failureCount.get() == 0 ? "PASSED" : "FAILED")); // no i18n
    }
    
    /**
     * Log API response details
     * @param operation Name of the operation
     * @param response API response object
     */
    private void logAPIResponse(String operation, APIResponse<?> response) {
        if (response != null) {
            LOGGER.info("  " + operation + " - Status: " + response.getStatusCode()); // no i18n
        } else {
            LOGGER.warning("  " + operation + " - Response is null"); // no i18n
        }
    }
    
    // ==================== HELPER CLASSES ====================
    
    /**
     * Helper class to store individual request results
     */
    private static class RequestResult {
        int threadId;
        boolean success;
        long duration;
        int statusCode;
        String errorMessage;
        
        RequestResult(int threadId, boolean success, long duration, int statusCode) {
            this.threadId = threadId;
            this.success = success;
            this.duration = duration;
            this.statusCode = statusCode;
        }
        
        RequestResult(int threadId, boolean success, long duration, int statusCode, String errorMessage) {
            this(threadId, success, duration, statusCode);
            this.errorMessage = errorMessage;
        }
    }
    
    /**
     * Helper class to store thread-level results
     */
    private static class ThreadResult {
        int threadId;
        int passed;
        int failed;
        long totalTime;
        
        ThreadResult(int threadId, int passed, int failed, long totalTime) {
            this.threadId = threadId;
            this.passed = passed;
            this.failed = failed;
            this.totalTime = totalTime;
        }
    }
}
