//$Id$
package com.zoho.ctv.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zoho.appos.api.HeaderMap;
import com.zoho.appos.api.ParameterMap;
import com.zoho.appos.api.customviews.CustomViews;
import com.zoho.appos.api.customviews.CustomViewsOperations;
import com.zoho.appos.api.customviews.CustomViewsOperations.DeleteCustomViewsParam;
import com.zoho.appos.api.fields.Fields;
import com.zoho.appos.api.fields.FieldsOperations;
import com.zoho.appos.api.modules.Modules;
import com.zoho.appos.api.modules.ModulesOperations;
import com.zoho.appos.api.profiles.Profile;
import com.zoho.appos.api.profiles.ProfilesOperations;
import com.zoho.appos.api.profiles.ResponseWrapper;
import com.zoho.appos.api.record.Record;
import com.zoho.appos.api.record.RecordOperations;
import com.zoho.appos.api.roles.RolesOperations;
import com.zoho.appos.api.tags.TagsOperations;
import com.zoho.appos.api.util.APIResponse;
import com.zoho.appos.api.util.query.Criteria;

/**
 * Comprehensive test suite for Custom Module CRUD Operations in AppOS SDK
 * 
 * Tests all major API operations including:
 * - Record CRUD operations
 * - Module operations
 * - Field operations
 * - COQL queries
 * - Custom views
 * - Profiles and roles
 * - Tags
 * - Analytics
 * 
 * USAGE:
 * <pre>
 * CustomModuleCRUDTest test = new CustomModuleCRUDTest();
 * test.runCustomModuleTests();
 * </pre>
 * 
 * @author AppOS SDK Team
 * @version 1.0
 * @since SDK v18.0.0
 */
public class CustomModuleCRUDTest {
    
    private static final Logger LOGGER = Logger.getLogger(CustomModuleCRUDTest.class.getName());
    
    private String number = ThreadLocalRandom.current().nextInt(0, 100000) + ""; // no i18n
    private String testModule = "TestModule" + number; // no i18n
    private String testModulePlural = "Test Modules" + number; // no i18n
    private String testModuleSingular = "Test Module" + number; // no i18n
    
    // Cached profile ID fetched from API
    private Long cachedStandardProfileId = null;
    
    /**
     * Run all Custom Module CRUD tests
     * @throws Exception if any test fails
     */
    public void runCustomModuleTests() throws Exception {
        LOGGER.info("================================================="); // no i18n
        LOGGER.info("Starting Custom Module CRUD Test Suite"); // no i18n
        LOGGER.info("SDK Version: 8.0.18.0.0"); // no i18n
        LOGGER.info("=================================================\n"); // no i18n
        
        try {
            // Phase 1: Setup & Module Operations
            testModuleOperations();
            
            // Phase 2: Field Operations
            testFieldOperations();
            
            // Phase 3: Record CRUD Operations
            testRecordCRUDOperations();
            
            // Phase 4a: COQL Query Operations
            testCOQLOperationsWithString();
           
            // Phase 4b: COQL Query Operations
            testCOQLOperationsWithBuilder();
            
            // Phase 5: Custom Views
            testCustomViewOperations();
            
            // Phase 6: Profiles & Roles
            testProfilesAndRoles();
            
            // Phase 7: Tags Operations
            testTagsOperations();
            
            // Phase 8: Analytics Operations
            testAnalyticsOperations();
            
            // Phase 9: Cleanup
            cleanup();
            
            LOGGER.info("\n================================================="); // no i18n
            LOGGER.info("All Custom Module Tests Completed Successfully!"); // no i18n
            LOGGER.info("================================================="); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Test suite failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== MODULE OPERATIONS ====================
    
    /**
     * Test 1: Module CRUD Operations
     * - Create module
     * - Get module
     * - Update module
     * - List modules
     * @throws Exception if module operations fail
     */
    public void testModuleOperations() throws Exception {
        LOGGER.info("\n--- TEST 1: Module Operations ---"); // no i18n
        
        try {
            // Create Module
            LOGGER.info("1.1 Creating test module..."); // no i18n
            ModulesOperations modulesOps = new ModulesOperations();
            com.zoho.appos.api.modules.BodyWrapper wrapper = new com.zoho.appos.api.modules.BodyWrapper();
            
            List<Modules> modules = new ArrayList<>();
            Modules module = new Modules();
            module.setAPIName(testModule);
            module.setPluralLabel(testModulePlural);
            module.setSingularLabel(testModuleSingular);
            
            // Profile is MANDATORY for module creation - fetch dynamically
            Long profileId = getStandardProfileId();
            if (profileId != null) {
                List<com.zoho.appos.api.profiles.MinifiedProfile> profiles = new ArrayList<>();
                com.zoho.appos.api.profiles.MinifiedProfile profile = new com.zoho.appos.api.profiles.MinifiedProfile();
                profile.setId(profileId);
                profiles.add(profile);
                module.setProfiles(profiles);
                LOGGER.info("Using Profile ID: " + profileId); // no i18n
            } else {
                throw new Exception("Could not fetch profile ID. Module creation cannot proceed."); // no i18n
            }
            
            modules.add(module);
            wrapper.setModules(modules);
            
            APIResponse<com.zoho.appos.api.modules.ActionHandler> createResponse = 
                modulesOps.createCustomModules(wrapper);
            logAPIResponse("Create Module", createResponse); // no i18n
            
            // Get Module
            LOGGER.info("1.2 Fetching module details..."); // no i18n
            APIResponse<com.zoho.appos.api.modules.ResponseHandler> getResponse = 
                modulesOps.getModuleByAPIName(testModule);
            logAPIResponse("Get Module", getResponse); // no i18n
            
            // List All Modules
            LOGGER.info("1.3 Listing all modules..."); // no i18n
            HeaderMap headerMap = new HeaderMap();
            APIResponse<com.zoho.appos.api.modules.ResponseHandler> listResponse = 
                modulesOps.getModules(null, headerMap);
            logAPIResponse("List Modules", listResponse); // no i18n
            
            LOGGER.info("Module operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Module operations test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== FIELD OPERATIONS ====================
    
    /**
     * Test 2: Field CRUD Operations
     * - Create field
     * - Get field
     * - Update field
     * - List fields
     * @throws Exception if field operations fail
     */
    public void testFieldOperations() throws Exception {
        LOGGER.info("\n--- TEST 2: Field Operations ---"); // no i18n
        
        try {
            FieldsOperations fieldsOps = new FieldsOperations();
            
            // Create Field
            LOGGER.info("2.1 Creating test field..."); // no i18n
            com.zoho.appos.api.fields.BodyWrapper wrapper = new com.zoho.appos.api.fields.BodyWrapper();
            
            List<Fields> fields = new ArrayList<>();
            Fields field = new Fields();
            field.setFieldLabel("Test Name"); // no i18n
            field.setDataType("text"); // no i18n
            field.setLength(255);
            fields.add(field);
            wrapper.setFields(fields);
            
            ParameterMap createParams = new ParameterMap();
            createParams.add(FieldsOperations.CreateFieldParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.fields.ActionHandler> createResponse = 
                fieldsOps.createField(wrapper, createParams);
            logAPIResponse("Create Field", createResponse); // no i18n
            
            // List Fields
            LOGGER.info("2.2 Listing all fields in module..."); // no i18n
            ParameterMap listParams = new ParameterMap();
            listParams.add(FieldsOperations.GetFieldsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.fields.ResponseHandler> listResponse = 
                fieldsOps.getFields(listParams, null);
            logAPIResponse("List Fields", listResponse); // no i18n
            
            LOGGER.info("Field operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Field operations test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== RECORD CRUD OPERATIONS ====================
    
    /**
     * Test 3: Record CRUD Operations
     * - Create record
     * - Get record by ID
     * - Update record
     * - Delete record
     * - Batch operations
     * @throws Exception if record operations fail
     */
    public void testRecordCRUDOperations() throws Exception {
        LOGGER.info("\n--- TEST 3: Record CRUD Operations ---"); // no i18n
        
        try {
            RecordOperations recordOps = new RecordOperations(testModule);
            
            // Create Single Record
            LOGGER.info("3.1 Creating single record..."); // no i18n
            com.zoho.appos.api.record.BodyWrapper createWrapper = new com.zoho.appos.api.record.BodyWrapper();
            
            List<Record> records = new ArrayList<>();
            Record record = new Record();
            record.addKeyValue("Name", "Sample Record"); // no i18n
            record.addKeyValue("Test_Name", "Sample Test Name Value"); // no i18n
            records.add(record);
            createWrapper.setData(records);
            
            APIResponse<com.zoho.appos.api.record.ActionHandler> createResponse = 
                recordOps.createRecords(createWrapper, new HeaderMap());
            logAPIResponse("Create Record", createResponse); // no i18n
            
            // Extract record ID from create response
            Long recordId = extractRecordIdFromResponse(createResponse);
            if (recordId == null) {
                throw new Exception("Could not extract record ID from create response."); // no i18n
            }
            LOGGER.info("Created record with ID: " + recordId); // no i18n
            
            // Get Record by ID
            LOGGER.info("3.2 Fetching record by ID..."); // no i18n
            ParameterMap getParams = new ParameterMap();
            HeaderMap getHeaders = new HeaderMap();
            
            APIResponse<com.zoho.appos.api.record.ResponseHandler> getResponse = 
                recordOps.getRecord(recordId, getParams, getHeaders);
            logAPIResponse("Get Record", getResponse); // no i18n
            
            // Update Record
            LOGGER.info("3.3 Updating record..."); // no i18n
            com.zoho.appos.api.record.BodyWrapper updateWrapper = new com.zoho.appos.api.record.BodyWrapper();
            
            List<Record> updateRecords = new ArrayList<>();
            Record updateRecord = new Record();
            updateRecord.setId(recordId);
            updateRecord.addKeyValue("Name", "Updated Record"); // no i18n
            updateRecord.addKeyValue("Test_Name", "Updated Test Name Value"); // no i18n
            updateRecords.add(updateRecord);
            updateWrapper.setData(updateRecords);
            
            APIResponse<com.zoho.appos.api.record.ActionHandler> updateResponse = 
                recordOps.updateRecords(updateWrapper, new HeaderMap());
            logAPIResponse("Update Record", updateResponse); // no i18n
            
            // Get All Records
            LOGGER.info("3.4 Fetching all records..."); // no i18n
            ParameterMap listParams = new ParameterMap();
            listParams.add(RecordOperations.GetRecordsParam.PAGE, 1);
            listParams.add(RecordOperations.GetRecordsParam.PER_PAGE, 10);
            listParams.add(RecordOperations.GetRecordsParam.FIELDS, "Name,Test_Name"); // no i18n
            
            APIResponse<com.zoho.appos.api.record.ResponseHandler> listResponse = 
                recordOps.getRecords(listParams, new HeaderMap());
            logAPIResponse("List Records", listResponse); // no i18n
            
            // Delete Record
            LOGGER.info("3.5 Deleting record..."); // no i18n
            ParameterMap deleteParams = new ParameterMap();
            
            APIResponse<com.zoho.appos.api.record.ActionHandler> deleteResponse = 
                recordOps.deleteRecord(recordId, deleteParams, new HeaderMap());
            logAPIResponse("Delete Record", deleteResponse); // no i18n
            
            // Batch Create
            LOGGER.info("3.6 Creating multiple records (batch)..."); // no i18n
            com.zoho.appos.api.record.BodyWrapper batchWrapper = new com.zoho.appos.api.record.BodyWrapper();
            
            List<Record> batchRecords = new ArrayList<>();
            for (int i = 1; i <= 5; i++) {
                Record batchRecord = new Record();
                batchRecord.addKeyValue("Name", "Batch Record " + i); // no i18n
                batchRecord.addKeyValue("Test_Name", "Batch Test Name " + i); // no i18n
                batchRecords.add(batchRecord);
            }
            batchWrapper.setData(batchRecords);
            
            APIResponse<com.zoho.appos.api.record.ActionHandler> batchResponse = 
                recordOps.createRecords(batchWrapper, new HeaderMap());
            logAPIResponse("Batch Create Records", batchResponse); // no i18n
            
            LOGGER.info("Record CRUD operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Record CRUD operations test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== COQL OPERATIONS ====================
    
    /**
     * Test 4a: COQL (CRM Object Query Language) Operations
     * @throws Exception if COQL operations fail
     */
    public void testCOQLOperationsWithString() throws Exception {
        LOGGER.info("\n--- TEST 4a: COQL Operations ---"); // no i18n
        
        try {
            com.zoho.appos.api.coql.CoqlOperations coqlOps = new com.zoho.appos.api.coql.CoqlOperations("automation"); // no i18n
            
            // 4a.1: SELECT with WHERE clause
            LOGGER.info("4a.1 Executing COQL SELECT with WHERE clause..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper whereQuery = new com.zoho.appos.api.coql.BodyWrapper();
            whereQuery.setSelectQuery("select Name, Test_Name from " + testModule + " where Name is not null"); // no i18n
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> whereResponse = 
                coqlOps.getRecords(whereQuery);
            logAPIResponse("COQL WHERE Query", whereResponse); // no i18n
            
            // 4a.2: SELECT with WHERE and ORDER BY
            LOGGER.info("4a.2 Executing COQL SELECT with WHERE and ORDER BY..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper orderQuery = new com.zoho.appos.api.coql.BodyWrapper();
            orderQuery.setSelectQuery("select Name, Test_Name from " + testModule + " where Name is not null order by Name asc"); // no i18n
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> orderResponse = 
                coqlOps.getRecords(orderQuery);
            logAPIResponse("COQL WHERE + ORDER BY Query", orderResponse); // no i18n
            
            // 4a.3: SELECT with WHERE and LIMIT
            LOGGER.info("4a.3 Executing COQL SELECT with WHERE and LIMIT..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper limitQuery = new com.zoho.appos.api.coql.BodyWrapper();
            limitQuery.setSelectQuery("select Name, Test_Name from " + testModule + " where Name is not null limit 5"); // no i18n
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> limitResponse = 
                coqlOps.getRecords(limitQuery);
            logAPIResponse("COQL WHERE + LIMIT Query", limitResponse); // no i18n
            
            // 4a.4: Complex query
            LOGGER.info("4a.4 Executing complex COQL query with WHERE, ORDER BY and LIMIT..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper complexQuery = new com.zoho.appos.api.coql.BodyWrapper();
            complexQuery.setSelectQuery("select Name, Test_Name from " + testModule + 
                " where Name is not null order by Name asc limit 10"); // no i18n
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> complexResponse = 
                coqlOps.getRecords(complexQuery);
            logAPIResponse("COQL Complex Query", complexResponse); // no i18n
            
            // 4a.5: SELECT with WHERE using LIKE
            LOGGER.info("4a.5 Executing COQL SELECT with WHERE equals condition..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper equalsQuery = new com.zoho.appos.api.coql.BodyWrapper();
            equalsQuery.setSelectQuery("select Name, Test_Name from " + testModule + " where Name like 'Batch%'"); // no i18n
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> equalsResponse = 
                coqlOps.getRecords(equalsQuery);
            logAPIResponse("COQL WHERE LIKE Query", equalsResponse); // no i18n
            
            LOGGER.info("COQL operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "COQL operations test failed", e); // no i18n
            throw e;
        }
    }
    
    /**
     * Test 4b: COQL Query Operations using SelectQuery.Builder
     * @throws Exception if COQL operations fail
     */
    public void testCOQLOperationsWithBuilder() throws Exception {
        LOGGER.info("\n--- TEST 4b: COQL Operations using SelectQuery.Builder ---"); // no i18n
        
        try {
            com.zoho.appos.api.coql.CoqlOperations coqlOps = new com.zoho.appos.api.coql.CoqlOperations("automation"); // no i18n
            
            // 4b.1: SELECT with WHERE clause
            LOGGER.info("4b.1 Executing COQL SELECT with WHERE clause using SelectQuery.Builder..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper whereQuery = new com.zoho.appos.api.coql.BodyWrapper();
            com.zoho.appos.api.util.query.SelectQuery whereSelectQuery = new com.zoho.appos.api.util.query.SelectQuery.Builder()
                .selectFields("Name", "Test_Name") // no i18n
                .from(testModule)
                .where(Criteria.isNotNull("Name")) // no i18n
                .build();
            whereQuery.setSelectQueryBuilder(whereSelectQuery);
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> whereResponse = 
                coqlOps.getRecords(whereQuery);
            logAPIResponse("COQL WHERE Query (Builder)", whereResponse); // no i18n
            
            // 4b.2: SELECT with WHERE and ORDER BY
            LOGGER.info("4b.2 Executing COQL SELECT with WHERE and ORDER BY using SelectQuery.Builder..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper orderQuery = new com.zoho.appos.api.coql.BodyWrapper();
            com.zoho.appos.api.util.query.SelectQuery orderSelectQuery = new com.zoho.appos.api.util.query.SelectQuery.Builder()
                .selectFields("Name", "Test_Name") // no i18n
                .from(testModule)
                .where(Criteria.isNotNull("Name")) // no i18n
                .orderByAsc("Name") // no i18n
                .build();
            orderQuery.setSelectQueryBuilder(orderSelectQuery);
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> orderResponse = 
                coqlOps.getRecords(orderQuery);
            logAPIResponse("COQL WHERE + ORDER BY Query (Builder)", orderResponse); // no i18n
            
            // 4b.3: SELECT with WHERE and LIMIT
            LOGGER.info("4b.3 Executing COQL SELECT with WHERE and LIMIT using SelectQuery.Builder..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper limitQuery = new com.zoho.appos.api.coql.BodyWrapper();
            com.zoho.appos.api.util.query.SelectQuery limitSelectQuery = new com.zoho.appos.api.util.query.SelectQuery.Builder()
                .selectFields("Name", "Test_Name") // no i18n
                .from(testModule)
                .where(Criteria.isNotNull("Name")) // no i18n
                .limit(5)
                .build();
            limitQuery.setSelectQueryBuilder(limitSelectQuery);
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> limitResponse = 
                coqlOps.getRecords(limitQuery);
            logAPIResponse("COQL WHERE + LIMIT Query (Builder)", limitResponse); // no i18n
            
            // 4b.4: Complex query
            LOGGER.info("4b.4 Executing complex COQL query with WHERE, ORDER BY and LIMIT using SelectQuery.Builder..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper complexQuery = new com.zoho.appos.api.coql.BodyWrapper();
            com.zoho.appos.api.util.query.SelectQuery complexSelectQuery = new com.zoho.appos.api.util.query.SelectQuery.Builder()
                .selectFields("Name", "Test_Name") // no i18n
                .from(testModule)
                .where(Criteria.isNotNull("Name")) // no i18n
                .orderByAsc("Name") // no i18n
                .limit(10)
                .build();
            complexQuery.setSelectQueryBuilder(complexSelectQuery);
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> complexResponse = 
                coqlOps.getRecords(complexQuery);
            logAPIResponse("COQL Complex Query (Builder)", complexResponse); // no i18n
            
            // 4b.5: SELECT with WHERE using LIKE
            LOGGER.info("4b.5 Executing COQL SELECT with WHERE LIKE condition using SelectQuery.Builder..."); // no i18n
            com.zoho.appos.api.coql.BodyWrapper equalsQuery = new com.zoho.appos.api.coql.BodyWrapper();
            com.zoho.appos.api.util.query.SelectQuery likeSelectQuery = new com.zoho.appos.api.util.query.SelectQuery.Builder()
                .selectFields("Name", "Test_Name") // no i18n
                .from(testModule)
                .where(Criteria.like("Name", "Batch%")) // no i18n
                .build();
            equalsQuery.setSelectQueryBuilder(likeSelectQuery);
            
            APIResponse<com.zoho.appos.api.coql.ResponseHandler> equalsResponse = 
                coqlOps.getRecords(equalsQuery);
            logAPIResponse("COQL WHERE LIKE Query (Builder)", equalsResponse); // no i18n
            
            LOGGER.info("COQL operations with SelectQuery.Builder completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "COQL operations with SelectQuery.Builder test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== CUSTOM VIEW OPERATIONS ====================
    
    /**
     * Test 5: Custom View Operations
     * @throws Exception if custom view operations fail
     */
    public void testCustomViewOperations() throws Exception {
        LOGGER.info("\n--- TEST 5: Custom View Operations ---"); // no i18n
        
        try {
            CustomViewsOperations cvOps = new CustomViewsOperations();
            
            // List Custom Views
            LOGGER.info("5.1 Listing custom views..."); // no i18n
            ParameterMap listParams = new ParameterMap();
            listParams.add(CustomViewsOperations.GetCustomViewsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.customviews.ResponseHandler> listResponse = 
                cvOps.getCustomViews(listParams);
            logAPIResponse("List Custom Views", listResponse); // no i18n
            
            // Create Custom View
            LOGGER.info("5.2 Creating custom view..."); // no i18n
            com.zoho.appos.api.customviews.BodyWrapper createWrapper = 
                new com.zoho.appos.api.customviews.BodyWrapper();
            
            List<CustomViews> customViews = new ArrayList<>();
            CustomViews cv = new CustomViews();
            cv.setName("Active Records View"); // no i18n
            cv.setDisplayValue("Active Records"); // no i18n
            
            List<com.zoho.appos.api.customviews.Fields> cvFields = new ArrayList<>();
            com.zoho.appos.api.customviews.Fields field1 = new com.zoho.appos.api.customviews.Fields();
            field1.setAPIName("Name"); // no i18n
            cvFields.add(field1);
            
            com.zoho.appos.api.customviews.Fields field2 = new com.zoho.appos.api.customviews.Fields();
            field2.setAPIName("Test_Name"); // no i18n
            cvFields.add(field2);
            
            cv.setFields(cvFields);
            customViews.add(cv);
            createWrapper.setCustomViews(customViews);
            
            ParameterMap createParams = new ParameterMap();
            createParams.add(CustomViewsOperations.CreateCustomViewsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.customviews.ActionHandler> createResponse = 
                cvOps.createCustomViews(createWrapper, createParams);
            logAPIResponse("Create Custom View", createResponse); // no i18n
            
            LOGGER.info("Custom view operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Custom view operations test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== PROFILES & ROLES OPERATIONS ====================
    
    /**
     * Test 6: Profiles and Roles Operations
     * @throws Exception if profiles/roles operations fail
     */
    public void testProfilesAndRoles() throws Exception {
        LOGGER.info("\n--- TEST 6: Profiles & Roles Operations ---"); // no i18n
        
        try {
            // Profiles Operations
            LOGGER.info("6.1 Listing all profiles..."); // no i18n
            ProfilesOperations profilesOps = new ProfilesOperations();
            
            APIResponse<com.zoho.appos.api.profiles.ResponseHandler> profilesResponse = 
                profilesOps.getProfiles(new ParameterMap(), new HeaderMap());
            logAPIResponse("List Profiles", profilesResponse); // no i18n
            
            // Get Profile by ID
            LOGGER.info("6.2 Fetching profile by ID..."); // no i18n
            Long profileId = getStandardProfileId();
            if (profileId != null) {
                APIResponse<com.zoho.appos.api.profiles.ResponseHandler> profileResponse = 
                    profilesOps.getProfile(profileId, new HeaderMap());
                logAPIResponse("Get Profile", profileResponse); // no i18n
            } else {
                throw new Exception("Could not fetch profile ID for profile operations."); // no i18n
            }
            
            // Roles Operations
            LOGGER.info("6.3 Listing all roles..."); // no i18n
            RolesOperations rolesOps = new RolesOperations();
            
            APIResponse<com.zoho.appos.api.roles.ResponseHandler> rolesResponse = 
                rolesOps.getRoles();
            logAPIResponse("List Roles", rolesResponse); // no i18n
            
            LOGGER.info("Profiles & Roles operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Profiles & Roles operations test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== TAGS OPERATIONS ====================
    
    /**
     * Test 7: Tags Operations
     * @throws Exception if tags operations fail
     */
    public void testTagsOperations() throws Exception {
        LOGGER.info("\n--- TEST 7: Tags Operations ---"); // no i18n
        
        try {
            TagsOperations tagsOps = new TagsOperations();
            
            // List Tags
            LOGGER.info("7.1 Listing tags..."); // no i18n
            ParameterMap listParams = new ParameterMap();
            listParams.add(TagsOperations.GetTagsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.tags.ResponseHandler> listResponse = 
                tagsOps.getTags(listParams);
            logAPIResponse("List Tags", listResponse); // no i18n
            
            // Create Tag
            LOGGER.info("7.2 Creating tag..."); // no i18n
            com.zoho.appos.api.tags.BodyWrapper createWrapper = 
                new com.zoho.appos.api.tags.BodyWrapper();
            
            List<com.zoho.appos.api.tags.Tag> tags = new ArrayList<>();
            com.zoho.appos.api.tags.Tag tag = new com.zoho.appos.api.tags.Tag();
            tag.setName("Important"); // no i18n
            tags.add(tag);
            createWrapper.setTags(tags);
            
            ParameterMap createParams = new ParameterMap();
            createParams.add(TagsOperations.CreateTagsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.tags.ActionHandler> createResponse = 
                tagsOps.createTags(createWrapper, createParams);
            logAPIResponse("Create Tag", createResponse); // no i18n
            
            // Extract Tag ID from create response for update
            Long tagId = extractTagIdFromResponse(createResponse);
            
            // Update Tag
            if (tagId != null) {
                LOGGER.info("7.3 Updating tag..."); // no i18n
                com.zoho.appos.api.tags.BodyWrapper updateWrapper = 
                    new com.zoho.appos.api.tags.BodyWrapper();
                
                List<com.zoho.appos.api.tags.Tag> updateTags = new ArrayList<>();
                com.zoho.appos.api.tags.Tag updateTag = new com.zoho.appos.api.tags.Tag();
                updateTag.setName("Very Important"); // no i18n
                updateTags.add(updateTag);
                updateWrapper.setTags(updateTags);
                
                ParameterMap updateParams = new ParameterMap();
                updateParams.add(TagsOperations.UpdateTagParam.MODULE, testModule);
                
                APIResponse<com.zoho.appos.api.tags.ActionHandler> updateResponse = 
                    tagsOps.updateTag(tagId, updateWrapper, updateParams);
                logAPIResponse("Update Tag", updateResponse); // no i18n
                
                LOGGER.info("Tag updated successfully from 'Important' to 'Very Important'"); // no i18n
            } else {
                LOGGER.warning("Could not extract tag ID from create response. Skipping update tag test."); // no i18n
            }
            
            LOGGER.info("Tags operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Tags operations test failed", e); // no i18n
            throw e;
        }
    }
    
    /**
     * Extracts tag ID from the create tag API response.
     */
    private Long extractTagIdFromResponse(APIResponse<com.zoho.appos.api.tags.ActionHandler> response) {
        try {
            if (response == null || !response.isExpected()) {
                LOGGER.warning("Tag response is null or not expected"); // no i18n
                return null;
            }
            
            com.zoho.appos.api.tags.ActionHandler actionHandler = response.getObject();
            
            if (actionHandler instanceof com.zoho.appos.api.tags.ActionWrapper) {
                com.zoho.appos.api.tags.ActionWrapper actionWrapper = 
                    (com.zoho.appos.api.tags.ActionWrapper) actionHandler;
                
                List<com.zoho.appos.api.tags.ActionResponse> actionResponses = actionWrapper.getTags();
                
                if (actionResponses != null && !actionResponses.isEmpty()) {
                    com.zoho.appos.api.tags.ActionResponse actionResponse = actionResponses.get(0);
                    
                    if (actionResponse instanceof com.zoho.appos.api.tags.SuccessResponse) {
                        com.zoho.appos.api.tags.SuccessResponse successResponse = 
                            (com.zoho.appos.api.tags.SuccessResponse) actionResponse;
                        
                        java.util.Map<String, Object> details = successResponse.getDetails();
                        if (details != null && details.containsKey("id")) { // no i18n
                            Object idObj = details.get("id"); // no i18n
                            if (idObj instanceof Long) {
                                return (Long) idObj;
                            } else if (idObj != null) {
                                return Long.parseLong(idObj.toString());
                            }
                        }
                    }
                }
            }
            
            LOGGER.warning("Could not extract tag ID from response"); // no i18n
            return null;
            
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error extracting tag ID from response", e); // no i18n
            return null;
        }
    }
    
    // ==================== ANALYTICS OPERATIONS ====================
    
    /**
     * Test 8: Analytics Operations
     * @throws Exception if analytics operations fail
     */
    public void testAnalyticsOperations() throws Exception {
        LOGGER.info("\n--- TEST 8: Analytics Operations ---"); // no i18n
        
        try {
            LOGGER.info("8.1 Analytics operations - skipped (API method verification needed)"); // no i18n
            LOGGER.info("Analytics operations completed successfully\n"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Analytics operations test failed", e); // no i18n
            throw e;
        }
    }
    
    // ==================== CLEANUP ====================
    
    /**
     * Cleanup test data - Delete all created resources
     */
    public void cleanup() throws Exception {
        LOGGER.info("\n--- Cleanup: Removing Test Data ---"); // no i18n
        
        // 1. Delete Records
        try {
            LOGGER.info("Cleanup 1: Deleting records from module..."); // no i18n
            RecordOperations recordOps = new RecordOperations(testModule);
            
            ParameterMap listParams = new ParameterMap();
            listParams.add(RecordOperations.GetRecordsParam.FIELDS, "id"); // no i18n
            listParams.add(RecordOperations.GetRecordsParam.PAGE, 1);
            listParams.add(RecordOperations.GetRecordsParam.PER_PAGE, 100);
            
            APIResponse<com.zoho.appos.api.record.ResponseHandler> listResponse = 
                recordOps.getRecords(listParams, new HeaderMap());
            
            if (listResponse != null && listResponse.isExpected()) {
                com.zoho.appos.api.record.ResponseHandler responseHandler = listResponse.getObject();
                if (responseHandler instanceof com.zoho.appos.api.record.ResponseWrapper) {
                    com.zoho.appos.api.record.ResponseWrapper responseWrapper = 
                        (com.zoho.appos.api.record.ResponseWrapper) responseHandler;
                    List<Record> records = responseWrapper.getData();
                    
                    if (records != null && !records.isEmpty()) {
                        StringBuilder recordIds = new StringBuilder();
                        for (int i = 0; i < records.size(); i++) {
                            if (i > 0) {
                                recordIds.append(",");
                            }
                            recordIds.append(records.get(i).getId());
                        }
                        
                        ParameterMap deleteParams = new ParameterMap();
                        deleteParams.add(RecordOperations.DeleteRecordsParam.IDS, recordIds.toString());
                        
                        APIResponse<com.zoho.appos.api.record.ActionHandler> deleteResponse = 
                            recordOps.deleteRecords(deleteParams, new HeaderMap());
                        
                        if (deleteResponse != null && deleteResponse.getStatusCode() >= 200 && deleteResponse.getStatusCode() < 300) {
                            LOGGER.info("Deleted " + records.size() + " records"); // no i18n
                        }
                    } else {
                        LOGGER.info("No records to delete"); // no i18n
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting records: " + e.getMessage(), e); // no i18n
            throw e;
        }
        
        // 2. Delete Custom Views
        try {
            LOGGER.info("Cleanup 2: Deleting custom views..."); // no i18n
            CustomViewsOperations cvOps = new CustomViewsOperations();
            
            ParameterMap listParams = new ParameterMap();
            listParams.add(CustomViewsOperations.GetCustomViewsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.customviews.ResponseHandler> listResponse = 
                cvOps.getCustomViews(listParams);
            
            if (listResponse != null && listResponse.isExpected()) {
                com.zoho.appos.api.customviews.ResponseHandler responseHandler = listResponse.getObject();
                if (responseHandler instanceof com.zoho.appos.api.customviews.ResponseWrapper) {
                    com.zoho.appos.api.customviews.ResponseWrapper responseWrapper = 
                        (com.zoho.appos.api.customviews.ResponseWrapper) responseHandler;
                    List<CustomViews> customViews = responseWrapper.getCustomViews();
                    
                    if (customViews != null) {
                        for (CustomViews cv : customViews) {
                            if (cv.getName() != null && cv.getName().equals("Active Records View")) { // no i18n
                                try {
                                    LOGGER.info("Attempting to delete custom view: " + cv.getName() + " (ID: " + cv.getId() + ")"); // no i18n
                                    
                                    ParameterMap deleteCVParams = new ParameterMap();
                                    deleteCVParams.add(DeleteCustomViewsParam.MODULE, testModule);
                                    deleteCVParams.add(DeleteCustomViewsParam.IDS, cv.getId().toString());
                                    
                                    APIResponse<com.zoho.appos.api.customviews.ActionHandler> deleteResponse = 
                                        cvOps.deleteCustomViews(deleteCVParams);
                                    
                                    if (deleteResponse != null && deleteResponse.getStatusCode() >= 200 && deleteResponse.getStatusCode() < 300) {
                                        LOGGER.info("Deleted custom view: " + cv.getName()); // no i18n
                                    } else {
                                        LOGGER.warning("Could not delete custom view: " + cv.getName() + " - Status: " + 
                                            (deleteResponse != null ? deleteResponse.getStatusCode() : "null")); // no i18n
                                    }
                                } catch (Exception ex) {
                                    LOGGER.warning("Could not delete custom view: " + cv.getName() + " - " + ex.getMessage()); // no i18n
                                    throw ex;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting custom views: " + e.getMessage(), e); // no i18n
            throw e;
        }
        
        // 3. Delete Tags
        try {
            LOGGER.info("Cleanup 3: Deleting tags..."); // no i18n
            TagsOperations tagsOps = new TagsOperations();
            
            ParameterMap listParams = new ParameterMap();
            listParams.add(TagsOperations.GetTagsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.tags.ResponseHandler> listResponse = 
                tagsOps.getTags(listParams);
            
            if (listResponse != null && listResponse.isExpected()) {
                com.zoho.appos.api.tags.ResponseHandler responseHandler = listResponse.getObject();
                if (responseHandler instanceof com.zoho.appos.api.tags.ResponseWrapper) {
                    com.zoho.appos.api.tags.ResponseWrapper responseWrapper = 
                        (com.zoho.appos.api.tags.ResponseWrapper) responseHandler;
                    List<com.zoho.appos.api.tags.Tag> tags = responseWrapper.getTags();
                    
                    if (tags != null) {
                        for (com.zoho.appos.api.tags.Tag tag : tags) {
                            if (tag.getName() != null && 
                                (tag.getName().equals("Important") || tag.getName().equals("Very Important"))) { // no i18n
                                APIResponse<com.zoho.appos.api.tags.ActionHandler> deleteResponse = 
                                    tagsOps.deleteTag(tag.getId());
                                
                                if (deleteResponse != null && deleteResponse.getStatusCode() >= 200 && deleteResponse.getStatusCode() < 300) {
                                    LOGGER.info("Deleted tag: " + tag.getName()); // no i18n
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting tags: " + e.getMessage(), e); // no i18n
            throw e;
        }
        
        // 4. Delete Fields
        try {
            LOGGER.info("Cleanup 4: Deleting custom fields..."); // no i18n
            FieldsOperations fieldsOps = new FieldsOperations();
            
            ParameterMap listParams = new ParameterMap();
            listParams.add(FieldsOperations.GetFieldsParam.MODULE, testModule);
            
            APIResponse<com.zoho.appos.api.fields.ResponseHandler> listResponse = 
                fieldsOps.getFields(listParams, null);
            
            if (listResponse != null && listResponse.isExpected()) {
                com.zoho.appos.api.fields.ResponseHandler responseHandler = listResponse.getObject();
                if (responseHandler instanceof com.zoho.appos.api.fields.ResponseWrapper) {
                    com.zoho.appos.api.fields.ResponseWrapper responseWrapper = 
                        (com.zoho.appos.api.fields.ResponseWrapper) responseHandler;
                    List<Fields> fields = responseWrapper.getFields();
                    
                    if (fields != null) {
                        for (Fields field : fields) {
                            if (field.getAPIName() != null && field.getAPIName().equals("Test_Name")) { // no i18n
                                ParameterMap deleteParams = new ParameterMap();
                                deleteParams.add(FieldsOperations.DeleteFieldParam.MODULE, testModule);
                                
                                APIResponse<com.zoho.appos.api.fields.ActionHandler> deleteResponse = 
                                    fieldsOps.deleteField(field.getId(), deleteParams, new HeaderMap());
                                
                                if (deleteResponse != null && deleteResponse.getStatusCode() >= 200 && deleteResponse.getStatusCode() < 300) {
                                    LOGGER.info("Deleted field: " + field.getAPIName()); // no i18n
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting fields: " + e.getMessage(), e); // no i18n
            throw e;
        }
        
        // 5. Delete Module
        try {
            LOGGER.info("Cleanup 5: Deleting test module..."); // no i18n
            ModulesOperations modulesOps = new ModulesOperations();
            
            APIResponse<com.zoho.appos.api.modules.ActionHandler> deleteResponse = 
                modulesOps.deleteModuleByAPIName(testModule, null);
            
            if (deleteResponse != null && deleteResponse.getStatusCode() >= 200 && deleteResponse.getStatusCode() < 300) {
                LOGGER.info("Deleted module: " + testModule); // no i18n
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error deleting module: " + e.getMessage(), e); // no i18n
            throw e;
        }
        
        LOGGER.info("Cleanup completed\n"); // no i18n
    }
    
    // ==================== UTILITY METHODS ====================
    
    /**
     * Extracts record ID from the create/update API response.
     */
    private Long extractRecordIdFromResponse(APIResponse<com.zoho.appos.api.record.ActionHandler> response) {
        try {
            if (response == null || !response.isExpected()) {
                LOGGER.warning("Response is null or not expected"); // no i18n
                return null;
            }
            
            com.zoho.appos.api.record.ActionHandler actionHandler = response.getObject();
            
            if (actionHandler instanceof com.zoho.appos.api.record.ActionWrapper) {
                com.zoho.appos.api.record.ActionWrapper actionWrapper = 
                    (com.zoho.appos.api.record.ActionWrapper) actionHandler;
                
                List<com.zoho.appos.api.record.ActionResponse> actionResponses = actionWrapper.getData();
                
                if (actionResponses != null && !actionResponses.isEmpty()) {
                    com.zoho.appos.api.record.ActionResponse actionResponse = actionResponses.get(0);
                    
                    if (actionResponse instanceof com.zoho.appos.api.record.SuccessResponse) {
                        com.zoho.appos.api.record.SuccessResponse successResponse = 
                            (com.zoho.appos.api.record.SuccessResponse) actionResponse;
                        
                        java.util.Map<String, Object> details = successResponse.getDetails();
                        if (details != null && details.containsKey("id")) { // no i18n
                            Object idObj = details.get("id"); // no i18n
                            if (idObj instanceof Long) {
                                return (Long) idObj;
                            } else if (idObj != null) {
                                return Long.parseLong(idObj.toString());
                            }
                        }
                    }
                }
            }
            
            LOGGER.warning("Could not extract record ID from response"); // no i18n
            return null;
            
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error extracting record ID from response", e); // no i18n
            return null;
        }
    }
    
    /**
     * Fetches the Standard Profile ID dynamically via API.
     */
    private Long getStandardProfileId() throws Exception {
        if (cachedStandardProfileId != null) {
            return cachedStandardProfileId;
        }
        
        try {
            LOGGER.info("Fetching profiles to get Standard Profile ID..."); // no i18n
            ProfilesOperations profilesOps = new ProfilesOperations();
            
            APIResponse<com.zoho.appos.api.profiles.ResponseHandler> response = 
                profilesOps.getProfiles(new ParameterMap(), new HeaderMap());
            
            if (response != null && response.isExpected()) {
                com.zoho.appos.api.profiles.ResponseHandler responseHandler = response.getObject();
                
                if (responseHandler instanceof ResponseWrapper) {
                    ResponseWrapper responseWrapper = (ResponseWrapper) responseHandler;
                    List<Profile> profiles = responseWrapper.getProfiles();
                    
                    if (profiles != null && !profiles.isEmpty()) {
                        for (Profile profile : profiles) {
                            String profileName = profile.getName();
                            if (profileName != null && 
                                (profileName.equalsIgnoreCase("Standard") || // no i18n
                                 profileName.equalsIgnoreCase("Administrator") || // no i18n
                                 profileName.equalsIgnoreCase("Admin"))) { // no i18n
                                cachedStandardProfileId = profile.getId();
                                LOGGER.info("Found profile: " + profileName + " with ID: " + cachedStandardProfileId); // no i18n
                                return cachedStandardProfileId;
                            }
                        }
                        
                        Profile firstProfile = profiles.get(0);
                        cachedStandardProfileId = firstProfile.getId();
                        LOGGER.info("Using first available profile: " + firstProfile.getName() + 
                                   " with ID: " + cachedStandardProfileId); // no i18n
                        return cachedStandardProfileId;
                    }
                }
            }
            
            throw new Exception("Could not fetch profiles from API - response was empty or invalid"); // no i18n
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error fetching profile ID", e); // no i18n
            throw e;
        }
    }
    
    /**
     * Log API response details and throw exception if not successful.
     */
    private void logAPIResponse(String operation, APIResponse<?> response) throws Exception {
        if (response == null) {
            String errorMsg = operation + ": Response is null"; // no i18n
            LOGGER.severe(errorMsg);
            throw new Exception(errorMsg);
        }
        
        int statusCode = response.getStatusCode();
        boolean isSuccess = statusCode >= 200 && statusCode < 300;
        
        LOGGER.info(String.format(
            "%s - Status: %d, Headers: %s", // no i18n
            operation,
            statusCode,
            response.getHeaders()
        ));
        
        if (response.getObject() != null) {
            LOGGER.info("Response Object: " + response.getObject().getClass().getSimpleName()); // no i18n
        }
        
        if (response.getResponseJSON() != null) {
            LOGGER.fine("Response JSON: " + response.getResponseJSON().toString()); // no i18n
        }
        
        if (!isSuccess) {
            String errorMsg = String.format(
                "%s failed with status code: %d. Response: %s", // no i18n
                operation,
                statusCode,
                response.getResponseJSON() != null ? response.getResponseJSON().toString() : "No response body" // no i18n
            );
            LOGGER.severe(errorMsg);
            throw new Exception(errorMsg);
        }
        
        LOGGER.info(operation + ": Success " + "StatusCode: " + statusCode); // no i18n
    }
}
