//$Id$
package com.zoho.ctv.test;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.zoho.appos.common.components.filestore.AppOSFileInfo;
import com.zoho.appos.common.components.filestore.AppOSResponse;
import com.zoho.appos.common.components.sas.PropertyUtil;
import com.zoho.appos.stratus.AppOSStratusSDKImpl;
import com.zoho.appos.stratus.AppOSStratusSDKImpl.Action;

@Controller
public class StratusSDKTest {
	private static final Logger LOGGER = Logger.getLogger(StratusSDKTest.class.getName());

	public void stratusCreateOrg(Long bAppOrgID) {
		AppOSStratusSDKImpl p=new AppOSStratusSDKImpl();
		try {
			String stratusOrg= p.createOrg(bAppOrgID.toString());
			if(stratusOrg!=null) {
				LOGGER.log(Level.INFO,"Stratus Org created/Available {0}",new Object[]{stratusOrg});
			}

			//						AppOSFileInfo f=new AppOSFileInfo();
			//						f.setBucketName("bapp-40");
			//						f.setProperty("isCorsPolicyNeeded", false);
			//						f.setProperty("is_public",true);
			//						f.setAction(Action.CREATEBUCKET.getAction());
			//			f.setAction(Action.DELETE.getAction());

			//	        File file = new File("/Users/zadmin/Downloads/image.png"); // change path as needed
			//		      //  File file1 = new File(""); // change path as needed
			//
			//			// Upload with stream
			//	        InputStream inputStream = new FileInputStream(file);
			//	        
			//	        BufferedInputStream bins = new BufferedInputStream(inputStream);
			//	        f.setId("image.png");
			////	        p.deletebucket(f);
			// f.setInputStream(bins);
			//p.add(f);
			//p.read(f);
			// p.delete(f);
			// p.addFile(f);
			//	p.add(f);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception occured while creating Org :: {0}",new Object[]{e});
		}
	}
	@GetMapping("/stratustesting")
	public ModelAndView stratusCreateAndDeleteOperation() throws Exception {
		String result="success";
		AppOSStratusSDKImpl p=new AppOSStratusSDKImpl();
		AppOSFileInfo f=new AppOSFileInfo();
		String bucketName="bapp-41";//NO I18N
		f.setBucketName(bucketName);
		//f.setProperty("isCorsPolicyNeeded", false);
		f.setProperty("is_public",true);
		f.setAction(Action.CREATEBUCKET.getAction());
		try {
			//Create Bucket
			AppOSResponse<AppOSFileInfo> bucket=p.add(f);
			if(bucket.getMessage().equals("Bucket created successfully")){
				LOGGER.log(Level.INFO,"Bucket Created :: {0}",new Object[]{bucketName});
				String filePath=PropertyUtil.getProperty("app.home") + File.separator+ "conf" + File.separator+"struts.zsd"; //NO I18N
		        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filePath))) {
				f.setAction(Action.CREATE.getAction());
				f.setId("struts.zsd");
				f.setInputStream(bis);
				AppOSResponse<AppOSFileInfo> stratusfileadd=p.add(f);
				if(stratusfileadd.getMessage().equals("File created successfully")){
					LOGGER.log(Level.INFO,"File Created :: {0}",new Object[]{f.getId()});
					f.setAction(Action.DELETE.getAction());
					AppOSResponse<AppOSFileInfo> stratusfiledelete=p.delete(f);
					if(stratusfiledelete.getMessage().equals("File deleted succesfully")){
						LOGGER.log(Level.INFO,"File Deleted {0} :: ",new Object[]{f.getId()});
						p.deletebucket(f);
						LOGGER.log(Level.INFO,"Bucket Deeleted {0} ::",new Object[]{f.getId()}); 
					}
					else {
						LOGGER.log(Level.INFO,"File Not deleted {0} ::", new Object[]{f.getId()});
						result= "failure";//NO I18N
					}
				}
				else {
					LOGGER.log(Level.INFO,"File Not Created {0} ::",new Object[]{f.getId()});
					p.deletebucket(f);
					result= "failure";//NO I18N
				}
		        }
		        catch (IOException e) {
					LOGGER.log(Level.SEVERE,"Exception occured while performing operations in Stratus :: {0}",new Object[]{e});
					result="failure";//NO I18N
		        }
			}
			else {
				result= "failure";//NO I18N
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,"Exception occured while performing operations in Stratus :: {0}",new Object[]{e});
			result="failure";
		}
		ModelAndView model = new ModelAndView("testing");//NO I18N
		model.addObject("status", result);
		return model;
	}
}
