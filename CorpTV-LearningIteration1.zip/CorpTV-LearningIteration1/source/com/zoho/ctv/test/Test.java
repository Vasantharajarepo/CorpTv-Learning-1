//$Id$
package com.zoho.ctv.test;

public abstract class Test implements Runnable {
	@Override
	public void run() {
		long i =10l;
	}

}
